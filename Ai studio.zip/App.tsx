import React, { useState, useEffect, useRef } from 'react';
import { Dashboard } from './components/Dashboard';
import { DueList } from './components/DueList';
import { SmartAddModal } from './components/SmartAddModal';
import { DueDetailModal } from './components/DueDetailModal';
import { DeleteConfirmationModal } from './components/DeleteConfirmationModal';
import { DynamicArchitectureDemo } from './components/DynamicArchitectureDemo';
import { PaymentModal } from './components/PaymentModal';
import { PaymentSection } from './components/PaymentSection';
import { StorageService } from './services/storageService';
import { isConfigured, testFirestoreConnection, db } from './services/firebase';
import { DueWithCustomer, PaymentStatus, DueItem, Customer, PromiseRecord, PaymentTransaction } from './types';
import { GeminiService } from './services/geminiService';
import { ModernButton, ModernCard, ModernBadge, ModernSpinner } from './utils/uiComponents';
import { animationPresets } from './utils/animations';
import { 
  LayoutGrid, 
  List, 
  Plus, 
  Bell, 
  MessageSquare, 
  Loader2, 
  Database, 
  WifiOff, 
  Zap, 
  DollarSign,
  Menu,
  X,
  Settings,
  User,
  TrendingUp,
  CreditCard,
  Calendar,
  Users,
  FileText,
  Activity
} from 'lucide-react';

const App = () => {
  const [dues, setDues] = useState<DueWithCustomer[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [payments, setPayments] = useState<PaymentTransaction[]>([]);
  const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'LIST' | 'PAYMENTS' | 'DYNAMIC_DEMO'>('DASHBOARD');
  const [isLoading, setIsLoading] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  
  // Refs for navigation
  const mobileMenuRef = useRef<HTMLDivElement>(null);
  const profileMenuRef = useRef<HTMLDivElement>(null);
  
  // Modal States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingDue, setEditingDue] = useState<DueWithCustomer | null>(null);
  
  // Payment Modal State
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [selectedDueForPayment, setSelectedDueForPayment] = useState<DueWithCustomer | null>(null);
  
  // Detail Modal State
  const [viewingDue, setViewingDue] = useState<DueWithCustomer | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  // Delete Confirmation Modal State
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{id: string, name: string} | null>(null);

  // Reminder State
  const [reminderModalOpen, setReminderModalOpen] = useState(false);
  const [reminderText, setReminderText] = useState('');
  const [reminderLoading, setReminderLoading] = useState(false);

  useEffect(() => {
    loadData();
    
    
    
    // Close mobile menu when clicking outside
    const handleClickOutside = (event: MouseEvent) => {
      if (mobileMenuRef.current && !mobileMenuRef.current.contains(event.target as Node)) {
        setIsMobileMenuOpen(false);
      }
      if (profileMenuRef.current && !profileMenuRef.current.contains(event.target as Node)) {
        setIsProfileMenuOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const loadData = async () => {
    console.log("📊 Starting to load data...");
    setIsLoading(true);
    try {
      console.log("📞 Loading all data...");
      
      // Load all data in parallel
      const [duesData, customersData, paymentsData] = await Promise.all([
        StorageService.getDuesWithCustomers(),
        StorageService.getCustomers(),
        StorageService.getPayments()
      ]);
      
      console.log("📈 Data loaded successfully:");
      console.log("- Dues:", duesData.length, "items");
      console.log("- Customers:", customersData.length, "items");
      console.log("- Payments:", paymentsData.length, "items");
      
      setDues(duesData);
      setCustomers(customersData);
      setPayments(paymentsData);
      
      console.log("✅ All data updated");
    } catch (error: any) {
      console.error("❌ Failed to load data:", error);
      console.error("Error details:", error.message);
      alert("Failed to load data. Please refresh.");
    } finally {
      setIsLoading(false);
      console.log("📊 Data loading completed");
    }
  };

  const handleSaveDue = async (formData: any) => {
    console.log("📋 Form data received:", formData);
    if (!formData.customerName || !formData.amount || !formData.title) {
      console.log("❌ Missing required fields:", { 
        customerName: formData.customerName, 
        amount: formData.amount, 
        title: formData.title 
      });
      return;
    }

    setIsLoading(true);

    try {
        console.log("🔍 Starting save process...");
        console.log("📝 Customer name:", formData.customerName);
        console.log("💰 Amount:", formData.amount);
        console.log("📋 Title:", formData.title);
        
        // Find or Create Customer
        let customerId = '';
        console.log("👥 Fetching existing customers...");
        const customers = await StorageService.getCustomers();
        console.log("📊 Found customers:", customers.length);
        
        const existingCustomer = customers.find(c => c.name.toLowerCase() === formData.customerName.toLowerCase());
        
        if (existingCustomer) {
          console.log("✅ Found existing customer:", existingCustomer.name, "ID:", existingCustomer.id);
          customerId = existingCustomer.id;
        } else {
          console.log("🆕 Creating new customer:", formData.customerName);
          const newCustomer: Customer = {
            id: `c_${Date.now()}`,
            name: formData.customerName,
            email: '',
            phone: ''
          };
          console.log("💾 Saving new customer to database...");
          await StorageService.saveCustomer(newCustomer);
          console.log("✅ New customer saved successfully");
          customerId = newCustomer.id;
        }

        // Logic to handle Promise History
        let promiseHistory = editingDue?.promiseHistory || [];
        const newAgreedDate = formData.lastPaymentAgreedDate;
        
        // If a new agreed date is set and it's different from the old one, add to history
        if (newAgreedDate && (!editingDue || editingDue.lastPaymentAgreedDate !== newAgreedDate)) {
          const newPromise: PromiseRecord = {
            id: `pr_${Date.now()}`,
            promisedDate: newAgreedDate,
            createdAt: new Date().toISOString(),
            status: 'PENDING',
            note: formData.shortNote || 'Promise date updated via form'
          };
          promiseHistory = [...promiseHistory, newPromise];
        }

        console.log("📋 Creating due item...");
        const due: DueItem = {
          id: editingDue ? editingDue.id : `d_${Date.now()}`,
          customerId,
          amount: parseFloat(formData.amount),
          paidAmount: editingDue ? editingDue.paidAmount : 0,
          dueDate: formData.dueDate,
          title: formData.title,
          status: editingDue ? editingDue.status : PaymentStatus.PENDING,
          createdAt: editingDue ? editingDue.createdAt : new Date().toISOString(),
          shortNote: formData.shortNote,
          lastPaymentDate: formData.lastPaymentDate || null,
          lastPaymentAgreedDate: formData.lastPaymentAgreedDate || null,
          paymentHistory: editingDue?.paymentHistory || [],
          promiseHistory: promiseHistory // Save the updated history
        };

        console.log("🚀 Attempting to save due:", due);
        console.log("📊 Due ID:", due.id);
        console.log("👤 Customer ID:", due.customerId);
        console.log("💰 Amount:", due.amount);
        
        await StorageService.saveDue(due);
        console.log("📊 Due saved successfully, reloading data...");
        await loadData(); // Reload to get fresh data
        console.log("🔄 Data reloaded successfully");
        setIsAddModalOpen(false);
        setEditingDue(null);
        console.log("✅ Save process completed successfully");
    } catch (error) {
        console.error("❌ Save error:", error);
        console.error("Error name:", (error as any).name);
        console.error("Error stack:", (error as any).stack);
        alert("Failed to save. Error: " + (error as Error).message);
        setIsLoading(false);
    }
  };

  const openAdd = () => {
    setEditingDue(null);
    setIsAddModalOpen(true);
  }

  const openEdit = (due: DueWithCustomer) => {
    setEditingDue(due);
    setIsAddModalOpen(true);
  };

  // Open the detail view
  const openDetails = (due: DueWithCustomer) => {
    setViewingDue(due);
    setIsDetailModalOpen(true);
  };

  const handleDelete = (id: string) => {
    const due = dues.find(d => d.id === id);
    if (due) {
      setItemToDelete({
        id: id,
        name: due.title || 'this due'
      });
      setDeleteModalOpen(true);
    }
  };

  const confirmDelete = async () => {
    if (!itemToDelete) return;
    
    setDeleteLoading(true);
    try {
      await StorageService.deleteDue(itemToDelete.id);
      // Update local state immediately for instant UI feedback
      setDues(prev => prev.filter(d => d.id !== itemToDelete.id));
      setDeleteModalOpen(false);
      setItemToDelete(null);
    } catch (error) {
      console.error('Error deleting due:', error);
      alert('Failed to delete due. Please try again.');
    } finally {
      setDeleteLoading(false);
    }
  };

  const closeDeleteModal = () => {
    setDeleteModalOpen(false);
    setItemToDelete(null);
    setDeleteLoading(false);
  };

  // Payment Handlers
  const handleAddPayment = (due: DueWithCustomer) => {
    setSelectedDueForPayment(due);
    setIsPaymentModalOpen(true);
  };

  const handleSavePayment = async (paymentData: {
    customerId: string;
    dueId: string;
    amount: number;
    paymentDate: string;
    paymentMethod: string;
    notes: string;
  }) => {
    try {
      console.log('💰 Saving payment:', paymentData);
      await StorageService.addPayment(paymentData);
      
      // Reload data to reflect changes
      await loadData();
      
      setIsPaymentModalOpen(false);
      setSelectedDueForPayment(null);
      console.log('✅ Payment saved successfully');
    } catch (error) {
      console.error('❌ Failed to save payment:', error);
      alert('Failed to save payment. Please try again.');
    }
  };

  const handleDeletePayment = async (paymentId: string) => {
    try {
      console.log('🗑️ Deleting payment:', paymentId);
      await StorageService.deletePayment(paymentId);
      await loadData();
      console.log('✅ Payment deleted successfully');
    } catch (error) {
      console.error('❌ Failed to delete payment:', error);
      alert('Failed to delete payment. Please try again.');
    }
  };

  const handleMarkPaid = async (id: string) => {
    const due = dues.find(d => d.id === id);
    if (due) {
      setIsLoading(true);
      const updatedDue = { ...due, status: PaymentStatus.PAID, paidAmount: due.amount };
      await StorageService.saveDue(updatedDue);
      await loadData();
      
      // If we are viewing details for this one, update the view state
      if (viewingDue && viewingDue.id === id) {
         setViewingDue({...viewingDue, ...updatedDue} as DueWithCustomer);
      }
    }
  };

  const handleGenerateReminder = async (due: DueWithCustomer) => {
    setReminderModalOpen(true);
    setReminderLoading(true);
    setReminderText('Generating polite reminder...');
    
    const text = await GeminiService.generateReminder(
      due.customer?.name || 'Customer', 
      due.amount - due.paidAmount, 
      due.dueDate, 
      'polite'
    );
    setReminderText(text || "Error generating reminder.");
    setReminderLoading(false);
  };

  // Notifications
  const overdueCount = dues.filter(d => d.status === PaymentStatus.OVERDUE).length;

  

  if (isLoading && dues.length === 0) {
      return (
          <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50 text-gray-600 gap-6">
              <div className="relative">
                  <div className="w-16 h-16 bg-gradient-primary rounded-2xl flex items-center justify-center shadow-glow-primary animate-pulse">
                      <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                          <div className="w-4 h-4 bg-gradient-primary rounded animate-bounce" />
                      </div>
                  </div>
                  <div className="absolute -inset-2 bg-gradient-primary/20 rounded-2xl blur-xl animate-pulse" />
              </div>
              <div className="text-center space-y-2">
                  <h2 className="text-xl font-bold text-gray-800 animate-fade-in">DueTrack AI</h2>
                  <p className="text-gray-600 animate-fade-in delay-200">Loading your financial dashboard...</p>
              </div>
              <ModernSpinner size="lg" variant="primary" gradient />
          </div>
      )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 text-gray-900 font-sans">
      
      {/* Modern Top Navigation */}
      <nav className="bg-white/80 backdrop-blur-xl border-b border-white/20 sticky top-0 z-50 px-4 py-4 shadow-soft">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Logo and Brand */}
          <div className="flex items-center gap-4">
            <div className="relative group">
              <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow-primary group-hover:scale-110 transition-transform duration-300">
                <div className="w-6 h-6 bg-white rounded-lg flex items-center justify-center">
                  <div className="w-3 h-3 bg-gradient-primary rounded animate-pulse" />
                </div>
              </div>
              <div className="absolute -inset-1 bg-gradient-primary/20 rounded-xl blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                DueTrack AI
              </h1>
              <p className="text-sm text-gray-500">Smart Financial Management</p>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center justify-center gap-3">
            <ModernButton
              variant={activeTab === 'DASHBOARD' ? 'primary' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('DASHBOARD')}
              gradientTransition
              active={activeTab === 'DASHBOARD'}
              gradientTone="primary"
              className={`${activeTab === 'DASHBOARD' ? 'shadow-glow-primary' : 'hover:shadow-medium'} group flex flex-col items-center justify-center gap-2 w-[100px] h-[70px] relative overflow-hidden transition-all duration-300`}
            >
              <div className="flex flex-col items-center justify-center gap-2">
                <div className={`${activeTab === 'DASHBOARD' ? 'bg-white/25' : 'bg-white/10 hover:bg-white/20'} p-2 rounded-xl transition-all duration-300 border border-white/15`}>
                  <LayoutGrid size={20} className={`${activeTab === 'DASHBOARD' ? 'text-white' : 'text-gray-600 group-hover:text-primary-600'} transition-all duration-300`} />
                </div>
                <span className={`${activeTab === 'DASHBOARD' ? 'text-white font-semibold' : 'text-gray-700 group-hover:text-primary-700'} text-[11px] font-medium transition-all duration-300`}>Dashboard</span>
              </div>
            </ModernButton>
            
            <ModernButton
              variant={activeTab === 'LIST' ? 'primary' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('LIST')}
              gradientTransition
              active={activeTab === 'LIST'}
              gradientTone="primary"
              className={`${activeTab === 'LIST' ? 'shadow-glow-primary' : 'hover:shadow-medium'} group flex flex-col items-center justify-center gap-2 w-[100px] h-[70px] relative overflow-hidden transition-all duration-300`}
            >
              <div className="flex flex-col items-center justify-center gap-2">
                <div className={`${activeTab === 'LIST' ? 'bg-white/25' : 'bg-white/10 hover:bg-white/20'} p-2 rounded-xl transition-all duration-300 border border-white/15`}>
                  <List size={20} className={`${activeTab === 'LIST' ? 'text-white' : 'text-gray-600 group-hover:text-primary-600'} transition-all duration-300`} />
                </div>
                <span className={`${activeTab === 'LIST' ? 'text-white font-semibold' : 'text-gray-700 group-hover:text-primary-700'} text-[11px] font-medium transition-all duration-300`}>Dues</span>
              </div>
            </ModernButton>
            
            <ModernButton
              variant={activeTab === 'PAYMENTS' ? 'primary' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('PAYMENTS')}
              gradientTransition
              active={activeTab === 'PAYMENTS'}
              gradientTone="primary"
              className={`${activeTab === 'PAYMENTS' ? 'shadow-glow-primary' : 'hover:shadow-medium'} group flex flex-col items-center justify-center gap-2 w-[100px] h-[70px] relative overflow-hidden transition-all duration-300`}
            >
              <div className="flex flex-col items-center justify-center gap-2">
                <div className={`${activeTab === 'PAYMENTS' ? 'bg-white/25' : 'bg-white/10 hover:bg-white/20'} p-2 rounded-xl transition-all duration-300 border border-white/15`}>
                  <DollarSign size={20} className={`${activeTab === 'PAYMENTS' ? 'text-white' : 'text-gray-600 group-hover:text-primary-600'} transition-all duration-300`} />
                </div>
                <span className={`${activeTab === 'PAYMENTS' ? 'text-white font-semibold' : 'text-gray-700 group-hover:text-primary-700'} text-[11px] font-medium transition-all duration-300`}>Payments</span>
              </div>
            </ModernButton>
            
            <ModernButton
              variant={activeTab === 'DYNAMIC_DEMO' ? 'primary' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('DYNAMIC_DEMO')}
              gradientTransition
              active={activeTab === 'DYNAMIC_DEMO'}
              gradientTone="primary"
              className={`${activeTab === 'DYNAMIC_DEMO' ? 'shadow-glow-primary' : 'hover:shadow-medium'} group flex flex-col items-center justify-center gap-2 w-[100px] h-[70px] relative overflow-hidden transition-all duration-300`}
            >
              <div className="flex flex-col items-center justify-center gap-2">
                <div className={`${activeTab === 'DYNAMIC_DEMO' ? 'bg-white/25' : 'bg-white/10 hover:bg-white/20'} p-2 rounded-xl transition-all duration-300 border border-white/15`}>
                  <Zap size={20} className={`${activeTab === 'DYNAMIC_DEMO' ? 'text-white' : 'text-gray-600 group-hover:text-primary-600'} transition-all duration-300`} />
                </div>
                <span className={`${activeTab === 'DYNAMIC_DEMO' ? 'text-white font-semibold' : 'text-gray-700 group-hover:text-primary-700'} text-[11px] font-medium transition-all duration-300`}>Demo</span>
              </div>
            </ModernButton>
          </div>
          
          {/* Right Side Actions */}
          <div className="flex items-center gap-4">
            {/* Notifications */}
            <div className="relative group">
              <ModernButton
                variant="ghost"
                size="sm"
                className="relative flex items-center justify-center w-10 h-10 rounded-xl border border-gray-200 hover:border-gray-300 transition-all duration-300"
              >
                <Bell size={18} className="text-gray-600 group-hover:text-primary-600 transition-colors" />
                {overdueCount > 0 && (
                  <ModernBadge
                    variant="danger"
                    size="sm"
                    className="absolute -top-1 -right-1 animate-bounce min-w-[18px] h-5 flex items-center justify-center text-xs"
                  >
                    {overdueCount}
                  </ModernBadge>
                )}
              </ModernButton>
              
              {/* Notification Dropdown */}
              <div className="absolute right-0 mt-2 w-80 bg-white/95 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 p-4 hidden group-hover:block animate-fade-in z-50">
                <div className="flex items-center gap-2 mb-3">
                  <Bell size={16} className="text-primary-600" />
                  <h3 className="font-semibold text-gray-800">Notifications</h3>
                </div>
                {overdueCount > 0 ? (
                  <ModernCard variant="glass" padding="sm" className="border-l-4 border-danger-500">
                    <p className="text-sm text-gray-700">
                      You have <span className="font-bold text-danger-600">{overdueCount}</span> overdue payments that need attention.
                    </p>
                  </ModernCard>
                ) : (
                  <ModernCard variant="glass" padding="sm" className="border-l-4 border-success-500">
                    <p className="text-sm text-gray-600">You're all caught up! Great job managing your finances.</p>
                  </ModernCard>
                )}
              </div>
            </div>
            
            {/* Profile Menu */}
            <div className="relative" ref={profileMenuRef}>
              <ModernButton
                variant="ghost"
                size="sm"
                onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                className="flex items-center justify-center w-10 h-10 rounded-xl border border-gray-200 hover:border-gray-300 transition-all duration-300"
              >
                <User size={18} className="text-gray-600" />
              </ModernButton>
              
              {/* Profile Dropdown */}
              {isProfileMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white/95 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 p-2 animate-scale-in z-50">
                  <button className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                    <Settings size={16} />
                    Settings
                  </button>
                  <button className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                    <Activity size={16} />
                    Activity
                  </button>
                  <hr className="my-2 border-gray-200" />
                  <button className="w-full flex items-center gap-3 px-3 py-2 text-sm text-danger-600 hover:bg-danger-50 rounded-lg transition-colors">
                    Sign Out
                  </button>
                </div>
              )}
            </div>
            
            {/* Add Due Button */}
            <ModernButton
              variant="primary"
              size="md"
              onClick={openAdd}
              gradient
              className="hidden sm:flex items-center gap-2 px-4 h-10 rounded-xl relative overflow-hidden"
            >
              <div className="flex items-center gap-2 relative z-10">
                <Plus size={16} />
                <span className="text-[12px] font-semibold">Add Due</span>
              </div>
              <span className="absolute inset-0 bg-gradient-primary rounded-xl" />
              <span className="absolute -inset-1 bg-gradient-primary opacity-15 blur-sm rounded-xl" style={{ transform: 'scale(0.95)' }} />
            </ModernButton>
            
            {/* Mobile Menu Button */}
            <ModernButton
              variant="ghost"
              size="sm"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden"
            >
              {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </ModernButton>
          </div>
        </div>
        
        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div ref={mobileMenuRef} className="lg:hidden mt-4 animate-slide-in-down">
            <div className="bg-white rounded-2xl shadow-xl border border-gray-200 p-4">
              <button
                onClick={() => { setActiveTab('DASHBOARD'); setIsMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-4 h-14 px-4 rounded-xl transition-all duration-200 ${activeTab === 'DASHBOARD' ? 'bg-blue-600 text-white shadow-lg' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50 hover:border-gray-300'}`}
              >
                <LayoutGrid size={20} className="flex-shrink-0" />
                <span className="font-medium">Dashboard</span>
              </button>
              
              <button
                onClick={() => { setActiveTab('LIST'); setIsMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-4 h-14 px-4 rounded-xl transition-all duration-200 mt-2 ${activeTab === 'LIST' ? 'bg-blue-600 text-white shadow-lg' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50 hover:border-gray-300'}`}
              >
                <List size={20} className="flex-shrink-0" />
                <span className="font-medium">All Dues</span>
              </button>
              
              <button
                onClick={() => { setActiveTab('PAYMENTS'); setIsMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-4 h-14 px-4 rounded-xl transition-all duration-200 mt-2 ${activeTab === 'PAYMENTS' ? 'bg-blue-600 text-white shadow-lg' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50 hover:border-gray-300'}`}
              >
                <DollarSign size={20} className="flex-shrink-0" />
                <span className="font-medium">Payments</span>
              </button>
              
              <button
                onClick={() => { setActiveTab('DYNAMIC_DEMO'); setIsMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-4 h-14 px-4 rounded-xl transition-all duration-200 mt-2 ${activeTab === 'DYNAMIC_DEMO' ? 'bg-blue-600 text-white shadow-lg' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50 hover:border-gray-300'}`}
              >
                <Zap size={20} className="flex-shrink-0" />
                <span className="font-medium">Dynamic Demo</span>
              </button>
              
              <hr className="my-4 border-gray-200" />
              
              <button
                onClick={() => { openAdd(); setIsMobileMenuOpen(false); }}
                className="w-full flex items-center gap-3 h-14 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
              >
                <Plus size={20} />
                <span>Add New Due</span>
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Enhanced Status Banner */}
      <div className="max-w-7xl mx-auto px-4 mt-4">
        {!isConfigured ? (
          <ModernCard variant="glass" className="border-l-4 border-warning-500">
            <div className="flex items-center gap-3">
              <WifiOff size={20} className="text-warning-600" />
              <div>
                <h3 className="font-semibold text-warning-800">Firebase Not Connected</h3>
                <p className="text-sm text-warning-600">Configure Firebase to enable real-time data synchronization</p>
              </div>
            </div>
          </ModernCard>
        ) : (
          <ModernCard variant="glass" className="border-l-4 border-success-500">
            <div className="flex items-center gap-3">
              <Database size={20} className="text-success-600" />
              <div>
                <h3 className="font-semibold text-success-800">Connected to Cloud</h3>
                <p className="text-sm text-success-600">Real-time data synchronization is active</p>
              </div>
            </div>
          </ModernCard>
        )}
      </div>

      {/* Modern Main Content */}
      <main className="max-w-7xl mx-auto p-4 md:p-6 lg:p-8 mt-6 pb-28 lg:pb-0">
        
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Enhanced Sidebar / Tabs (Desktop) */}
          <aside className="w-full lg:w-72 flex-shrink-0 hidden lg:block">
            <ModernCard variant="elevated" className="sticky top-28 animate-slide-in-left">
              <div className="p-6 space-y-4">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
                    <LayoutGrid size={20} className="text-white" />
                  </div>
                  <div>
                    <h2 className="font-bold text-gray-800">Navigation</h2>
                    <p className="text-sm text-gray-500">Quick access</p>
                  </div>
                </div>
                
                <nav className="space-y-3">
                  <ModernButton
                    variant={activeTab === 'DASHBOARD' ? 'primary' : 'ghost'}
                    size="md"
                    onClick={() => setActiveTab('DASHBOARD')}
                    gradientTransition
                    active={activeTab === 'DASHBOARD'}
                    gradientTone="primary"
                    className={`group w-full flex items-center gap-4 justify-start relative overflow-hidden ${activeTab === 'DASHBOARD' ? 'shadow-glow-primary' : 'hover:shadow-medium'} h-16 px-4`}
                  >
                    <div className={`${activeTab === 'DASHBOARD' ? 'bg-white/25' : ''} p-3 rounded-xl transition-all duration-300`}>
                      <LayoutGrid size={22} className={`${activeTab === 'DASHBOARD' ? 'text-white' : 'text-gray-600 group-hover:text-primary-600'} transition-all duration-300`} />
                    </div>
                    <div className="text-left">
                      <div className={`font-semibold ${activeTab === 'DASHBOARD' ? 'text-white' : 'text-gray-800 group-hover:text-primary-700'} transition-all duration-300`}>Dashboard</div>
                      <div className={`text-sm ${activeTab === 'DASHBOARD' ? 'text-white/90' : 'text-gray-500 group-hover:text-primary-600/80'} transition-all duration-300`}>Overview & Analytics</div>
                    </div>
                  </ModernButton>
                  
                  <ModernButton
                    variant={activeTab === 'LIST' ? 'primary' : 'ghost'}
                    size="md"
                    onClick={() => setActiveTab('LIST')}
                    gradientTransition
                    active={activeTab === 'LIST'}
                    gradientTone="primary"
                    className={`group w-full flex items-center gap-4 justify-start relative overflow-hidden ${activeTab === 'LIST' ? 'shadow-glow-primary' : 'hover:shadow-medium'} h-16 px-4`}
                  >
                    <div className={`${activeTab === 'LIST' ? 'bg-white/25' : ''} p-3 rounded-xl transition-all duration-300`}>
                      <List size={22} className={`${activeTab === 'LIST' ? 'text-white' : 'text-gray-600 group-hover:text-primary-600'} transition-all duration-300`} />
                    </div>
                    <div className="text-left">
                      <div className={`font-semibold ${activeTab === 'LIST' ? 'text-white' : 'text-gray-800 group-hover:text-primary-700'} transition-all duration-300`}>All Dues</div>
                      <div className={`text-sm ${activeTab === 'LIST' ? 'text-white/90' : 'text-gray-500 group-hover:text-primary-600/80'} transition-all duration-300`}>Manage payments</div>
                    </div>
                  </ModernButton>
                  
                  <ModernButton
                    variant={activeTab === 'PAYMENTS' ? 'primary' : 'ghost'}
                    size="md"
                    onClick={() => setActiveTab('PAYMENTS')}
                    gradientTransition
                    active={activeTab === 'PAYMENTS'}
                    gradientTone="primary"
                    className={`group w-full flex items-center gap-4 justify-start relative overflow-hidden ${activeTab === 'PAYMENTS' ? 'shadow-glow-primary' : 'hover:shadow-medium'} h-16 px-4`}
                  >
                    <div className={`${activeTab === 'PAYMENTS' ? 'bg-white/25' : ''} p-3 rounded-xl transition-all duration-300`}>
                      <DollarSign size={22} className={`${activeTab === 'PAYMENTS' ? 'text-white' : 'text-gray-600 group-hover:text-primary-600'} transition-all duration-300`} />
                    </div>
                    <div className="text-left">
                      <div className={`font-semibold ${activeTab === 'PAYMENTS' ? 'text-white' : 'text-gray-800 group-hover:text-primary-700'} transition-all duration-300`}>Payments</div>
                      <div className={`text-sm ${activeTab === 'PAYMENTS' ? 'text-white/90' : 'text-gray-500 group-hover:text-primary-600/80'} transition-all duration-300`}>Track transactions</div>
                    </div>
                  </ModernButton>
                  
                  <ModernButton
                    variant={activeTab === 'DYNAMIC_DEMO' ? 'primary' : 'ghost'}
                    size="md"
                    onClick={() => setActiveTab('DYNAMIC_DEMO')}
                    gradientTransition
                    active={activeTab === 'DYNAMIC_DEMO'}
                    gradientTone="primary"
                    className={`group w-full flex items-center gap-4 justify-start relative overflow-hidden ${activeTab === 'DYNAMIC_DEMO' ? 'shadow-glow-primary' : 'hover:shadow-medium'} h-16 px-4`}
                  >
                    <div className={`${activeTab === 'DYNAMIC_DEMO' ? 'bg-white/25' : ''} p-3 rounded-xl transition-all duration-300`}>
                      <Zap size={22} className={`${activeTab === 'DYNAMIC_DEMO' ? 'text-white' : 'text-gray-600 group-hover:text-primary-600'} transition-all duration-300`} />
                    </div>
                    <div className="text-left">
                      <div className={`font-semibold ${activeTab === 'DYNAMIC_DEMO' ? 'text-white' : 'text-gray-800 group-hover:text-primary-700'} transition-all duration-300`}>Dynamic Demo</div>
                      <div className={`text-sm ${activeTab === 'DYNAMIC_DEMO' ? 'text-white/90' : 'text-gray-500 group-hover:text-primary-600/80'} transition-all duration-300`}>Live features</div>
                    </div>
                  </ModernButton>
                </nav>
                
                <div className="pt-4 border-t border-gray-200">
                  <ModernButton
                    variant="primary"
                    size="lg"
                    onClick={openAdd}
                    gradient
                    glow
                    className="w-full flex items-center gap-3 justify-center"
                  >
                    <Plus size={20} />
                    Add New Due
                  </ModernButton>
                </div>
              </div>
            </ModernCard>
          </aside>

          {/* Enhanced Content Area */}
          <div className="flex-1">
             {/* Mobile Header */}
             <div className="mb-8 lg:hidden">
               <ModernCard variant="elevated" className="p-6">
                 <div className="flex items-center justify-between">
                   <div>
                     <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                       {activeTab === 'DASHBOARD' ? 'Dashboard' : 
                        activeTab === 'LIST' ? 'All Dues' : 
                        activeTab === 'PAYMENTS' ? 'Payment Management' :
                        activeTab === 'DYNAMIC_DEMO' ? 'Dynamic Demo' :
                        'Dashboard'}
                     </h1>
                     <p className="text-sm text-gray-500 mt-1">
                       {activeTab === 'DASHBOARD' ? 'Financial overview and analytics' :
                        activeTab === 'LIST' ? 'Manage your due payments' :
                        activeTab === 'PAYMENTS' ? 'Track payment transactions' :
                        activeTab === 'DYNAMIC_DEMO' ? 'Experience live features' :
                        'Welcome back'}
                     </p>
                   </div>
                   <ModernButton
                     variant="primary"
                     size="md"
                     onClick={openAdd}
                     gradient
                     glow
                     className="sm:hidden"
                   >
                     <Plus size={18} />
                   </ModernButton>
                 </div>
               </ModernCard>
             </div>

             {/* Animated Content Transitions */}
             <div className="animate-fade-in">
               {activeTab === 'DASHBOARD' && <Dashboard dues={dues} />}
               {activeTab === 'LIST' && (
                 <DueList 
                   dues={dues} 
                   onEdit={openEdit} 
                   onDelete={handleDelete} 
                   onMarkPaid={handleMarkPaid}
                   onGenerateReminder={handleGenerateReminder}
                   onViewDetails={openDetails}
                   onAddPayment={handleAddPayment}
                 />
               )}
               {activeTab === 'PAYMENTS' && (
                 <PaymentSection 
                   payments={payments}
                   customers={customers}
                   dues={dues}
                   onDeletePayment={handleDeletePayment}
                 />
               )}
               {activeTab === 'DYNAMIC_DEMO' && <DynamicArchitectureDemo />}
             </div>
          </div>
        </div>
      </main>

      {/* Modern Mobile Floating Action Button */}
      <div className="lg:hidden fixed bottom-24 right-6 z-50">
        <ModernButton
          variant="primary"
          size="lg"
          onClick={openAdd}
          gradient
          glow
          className="w-16 h-16 p-0 rounded-full shadow-2xl flex items-center justify-center transform hover:scale-110 active:scale-95 transition-all duration-200"
        >
          <Plus size={28} />
        </ModernButton>
      </div>

      {/* Modern Mobile Bottom Navigation */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-gradient-to-r from-white/95 via-white/90 to-white/95 backdrop-blur-xl border-t border-white/30 z-40 px-6 py-3 shadow-lg">
        <div className="flex justify-between items-center max-w-md mx-auto">
          <button 
            onClick={() => setActiveTab('DASHBOARD')}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl transition-all duration-300 ${
              activeTab === 'DASHBOARD' 
                ? 'text-white bg-gradient-primary shadow-glow-primary ring-1 ring-white/30' 
                : 'text-gray-600 hover:text-primary-700 hover:bg-gray-50 border border-gray-200'
            }`}
          >
            <LayoutGrid size={18} />
            <span className="text-[12px] font-semibold tracking-wide">Home</span>
          </button>
          
          <button 
            onClick={() => setActiveTab('LIST')}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl transition-all duration-300 ${
              activeTab === 'LIST' 
                ? 'text-white bg-gradient-primary shadow-glow-primary ring-1 ring-white/30' 
                : 'text-gray-600 hover:text-primary-700 hover:bg-gray-50 border border-gray-200'
            }`}
          >
            <List size={18} />
            <span className="text-[12px] font-semibold tracking-wide">Dues</span>
          </button>
          
          <button 
            onClick={() => setActiveTab('PAYMENTS')}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl transition-all duration-300 ${
              activeTab === 'PAYMENTS' 
                ? 'text-white bg-gradient-primary shadow-glow-primary ring-1 ring-white/30' 
                : 'text-gray-600 hover:text-primary-700 hover:bg-gray-50 border border-gray-200'
            }`}
          >
            <DollarSign size={18} />
            <span className="text-[12px] font-semibold tracking-wide">Payments</span>
          </button>
          
          <button 
            onClick={() => setActiveTab('DYNAMIC_DEMO')}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl transition-all duration-300 ${
              activeTab === 'DYNAMIC_DEMO' 
                ? 'text-white bg-gradient-primary shadow-glow-primary ring-1 ring-white/30' 
                : 'text-gray-600 hover:text-primary-700 hover:bg-gray-50 border border-gray-200'
            }`}
          >
            <Zap size={18} />
            <span className="text-[12px] font-semibold tracking-wide">Demo</span>
          </button>
        </div>
      </div>

      {/* Unified Add/Edit Modal */}
      {isAddModalOpen && (
        <SmartAddModal
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          onSave={handleSaveDue}
          editingDue={editingDue ? { 
            ...editingDue, 
            customerName: editingDue.customer?.name // HACK: Pass name into DueItem for Form
          } as any : null}
        />
      )}

      {/* Full Detail Modal */}
      {isDetailModalOpen && viewingDue && (
        <DueDetailModal 
          due={viewingDue}
          isOpen={isDetailModalOpen}
          onClose={() => setIsDetailModalOpen(false)}
          onMarkPaid={handleMarkPaid}
          onGenerateReminder={handleGenerateReminder}
        />
      )}

      {/* Modern Reminder Preview Modal */}
      {reminderModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[70] flex items-center justify-center p-4 animate-fade-in">
          <ModernCard variant="elevated" className="w-full max-w-lg animate-scale-in">
            <div className="p-6 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center">
                  <MessageSquare size={20} className="text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-800">AI Reminder Draft</h2>
                  <p className="text-sm text-gray-500">Generated by our AI assistant</p>
                </div>
              </div>
              
              <div className="bg-gradient-to-br from-gray-50 to-blue-50 p-4 rounded-xl border border-gray-200 min-h-[120px]">
                {reminderLoading ? (
                  <div className="flex items-center gap-3 text-gray-500">
                    <div className="w-5 h-5 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />
                    <span>AI is crafting your personalized reminder...</span>
                  </div>
                ) : (
                  <div className="text-gray-700 text-sm leading-relaxed whitespace-pre-wrap animate-fade-in">
                    {reminderText}
                  </div>
                )}
              </div>
              
              <div className="flex gap-3 justify-end">
                <ModernButton
                  variant="ghost"
                  size="md"
                  onClick={() => setReminderModalOpen(false)}
                >
                  Close
                </ModernButton>
                <ModernButton
                  variant="primary"
                  size="md"
                  onClick={() => {
                    navigator.clipboard.writeText(reminderText);
                    // Modern toast notification instead of alert
                    const toast = document.createElement('div');
                    toast.className = 'fixed top-4 right-4 bg-success-500 text-white px-4 py-2 rounded-lg shadow-lg animate-slide-in-right z-50';
                    toast.textContent = '✓ Copied to clipboard!';
                    document.body.appendChild(toast);
                    setTimeout(() => toast.remove(), 3000);
                  }}
                  disabled={reminderLoading}
                  gradient
                >
                  Copy Text
                </ModernButton>
              </div>
            </div>
          </ModernCard>
        </div>
      )}

      {/* Modern Delete Confirmation Modal */}
      <DeleteConfirmationModal
        isOpen={deleteModalOpen}
        onClose={closeDeleteModal}
        onConfirm={confirmDelete}
        itemName={itemToDelete?.name || 'this item'}
        isLoading={deleteLoading}
      />

      {/* Modern Payment Modal */}
      {isPaymentModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[70] flex items-center justify-center p-4 animate-fade-in">
          <PaymentModal
            isOpen={isPaymentModalOpen}
            onClose={() => {
              setIsPaymentModalOpen(false);
              setSelectedDueForPayment(null);
            }}
            onSave={handleSavePayment}
            customers={customers}
            dues={dues}
            selectedCustomer={selectedDueForPayment?.customer}
            selectedDue={selectedDueForPayment}
          />
        </div>
      )}

    </div>
  );
};

export default App;