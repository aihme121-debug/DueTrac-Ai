import { initializeApp } from "firebase/app";
import { getFirestore, Firestore, setDoc, doc, getDocs, collection, deleteDoc } from "firebase/firestore";

// Configuration provided by user
const firebaseConfig = {
  apiKey: "AIzaSyA4LFmYUK34TEMlK7o-SCPBdgZpNyZ8KJ8",
  authDomain: "dueall-27bff.firebaseapp.com",
  projectId: "dueall-27bff",
  storageBucket: "dueall-27bff.firebasestorage.app",
  messagingSenderId: "132561668068",
  appId: "1:132561668068:web:fae6325cb5c9d8e71569f1",
  measurementId: "G-0NGHKE44YD"
};

let db: Firestore | null = null;
let initError: string | null = null;
let isConfigured = false;

try {
  console.log("Attempting Firebase initialization...");
  console.log("Firebase config:", JSON.stringify(firebaseConfig, null, 2));
  
  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  console.log("Firebase app initialized:", app.name);
  
  // Initialize Cloud Firestore and get a reference to the service
  db = getFirestore(app);
  
  // Enable offline persistence to handle network issues better
  try {
    // Note: enablePersistence() should be called before any other Firestore operations
    console.log("Enabling Firestore offline persistence...");
  } catch (persistError) {
    console.warn("⚠️ Could not enable offline persistence:", persistError);
  }
  
  console.log("Firestore instance created successfully");
  isConfigured = true;
  console.log("✅ Firebase initialized successfully");
} catch (error: any) {
  console.error("❌ Firebase Initialization Error:", error);
  console.error("Error details:", error.message);
  console.error("Stack trace:", error.stack);
  initError = error.message;
}

// Test Firestore connection and permissions
export const testFirestoreConnection = async () => {
  if (!db) {
    console.error("❌ Firestore not initialized");
    return false;
  }
  
  try {
    console.log("🔍 Testing Firestore connection...");
    
    // Try to write a test document
    const testDoc = {
      test: true,
      timestamp: new Date().toISOString(),
      message: "Connection test"
    };
    
    await setDoc(doc(db, "test", "connection"), testDoc);
    console.log("✅ Firestore write test successful");
    
    // Try to read it back
    const snapshot = await getDocs(collection(db, "test"));
    console.log("✅ Firestore read test successful, docs found:", snapshot.size);
    
    // Clean up
    await deleteDoc(doc(db, "test", "connection"));
    console.log("✅ Firestore cleanup successful");
    
    return true;
  } catch (error) {
    console.error("❌ Firestore connection test failed:", error);
    return false;
  }
};

export { db, initError, isConfigured };