import React, { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { DueItem, PaymentStatus } from '../types';
import { 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  DollarSign, 
  Users, 
  Calendar,
  Activity,
  Target,
  BarChart3
} from 'lucide-react';
import { ModernCard, ModernBadge, ModernProgress } from '../utils/uiComponents';

interface DashboardProps {
  dues: DueItem[];
}

export const Dashboard: React.FC<DashboardProps> = ({ dues }) => {
  const [animatedValues, setAnimatedValues] = useState({
    totalOutstanding: 0,
    overdue: 0,
    collected: 0,
    pending: 0,
    collectionRate: 0
  });

  const totalDue = dues.reduce((acc, curr) => acc + curr.amount, 0);
  const paid = dues.filter(d => d.status === PaymentStatus.PAID).reduce((acc, curr) => acc + curr.amount, 0);
  const overdue = dues.filter(d => d.status === PaymentStatus.OVERDUE).reduce((acc, curr) => acc + (curr.amount - curr.paidAmount), 0);
  const pending = dues.filter(d => d.status === PaymentStatus.PENDING).reduce((acc, curr) => acc + (curr.amount - curr.paidAmount), 0);
  const partial = dues.filter(d => d.status === PaymentStatus.PARTIAL).reduce((acc, curr) => acc + (curr.amount - curr.paidAmount), 0);
  
  const collectionRate = totalDue > 0 ? Math.round((paid / totalDue) * 100) : 0;

  // Animate numbers on load
  useEffect(() => {
    const duration = 1500;
    const steps = 60;
    const interval = duration / steps;
    
    let currentStep = 0;
    const timer = setInterval(() => {
      currentStep++;
      const progress = currentStep / steps;
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      
      setAnimatedValues({
        totalOutstanding: Math.round((overdue + pending) * easeOutQuart),
        overdue: Math.round(overdue * easeOutQuart),
        collected: Math.round(paid * easeOutQuart),
        pending: Math.round(pending * easeOutQuart),
        collectionRate: Math.round(collectionRate * easeOutQuart)
      });
      
      if (currentStep >= steps) {
        clearInterval(timer);
      }
    }, interval);
    
    return () => clearInterval(timer);
  }, [overdue, pending, paid, collectionRate]);

  const pieData = [
    { name: 'Paid', value: paid, color: '#22c55e', icon: CheckCircle },
    { name: 'Overdue', value: overdue, color: '#ef4444', icon: AlertTriangle },
    { name: 'Pending', value: pending, color: '#f59e0b', icon: Clock },
    { name: 'Partial', value: partial, color: '#8b5cf6', icon: Activity },
  ].filter(d => d.value > 0);

  const monthlyData = [
    { month: 'Jan', collected: 12000, due: 15000 },
    { month: 'Feb', collected: 18000, due: 20000 },
    { month: 'Mar', collected: 22000, due: 25000 },
    { month: 'Apr', collected: 19000, due: 22000 },
    { month: 'May', collected: 25000, due: 28000 },
    { month: 'Jun', collected: 21000, due: 24000 },
  ];

  const StatCard = ({ 
    title, 
    value, 
    icon: Icon, 
    color, 
    subtitle, 
    trend 
  }: { 
    title: string; 
    value: string | number; 
    icon: any; 
    color: string; 
    subtitle: string; 
    trend?: { value: number; isPositive: boolean };
  }) => (
    <ModernCard 
      variant="elevated" 
      className="group hover:scale-105 transition-all duration-300 animate-slide-in-up"
      hover
      glow
    >
      <div className="p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className={`w-12 h-12 ${color} rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow`}>
            <Icon size={20} className="text-white" />
          </div>
          {trend && (
            <ModernBadge 
              variant={trend.isPositive ? 'success' : 'danger'} 
              size="sm"
              className="animate-fade-in"
            >
              {trend.isPositive ? '+' : ''}{trend.value}%
            </ModernBadge>
          )}
        </div>
        
        <div className="space-y-2">
          <div className="text-3xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
            ${typeof value === 'number' ? value.toLocaleString() : value}
          </div>
          <div className="text-sm font-medium text-gray-600 uppercase tracking-wide">{title}</div>
          <div className="text-xs text-gray-500 flex items-center gap-1">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            {subtitle}
          </div>
        </div>
        
        <ModernProgress 
          value={75} 
          max={100} 
          variant={color.includes('red') ? 'danger' : color.includes('green') ? 'success' : color.includes('yellow') ? 'warning' : 'primary'}
          gradient
          animated
          className="mt-4"
        />
      </div>
    </ModernCard>
  );

  return (
    <div className="space-y-8">
      {/* Animated Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Outstanding"
          value={animatedValues.totalOutstanding}
          icon={DollarSign}
          color="bg-gradient-primary"
          subtitle="Track actively"
          trend={{ value: 12, isPositive: false }}
        />
        
        <StatCard
          title="Overdue"
          value={animatedValues.overdue}
          icon={AlertTriangle}
          color="bg-gradient-danger"
          subtitle="Needs attention"
          trend={{ value: 8, isPositive: false }}
        />
        
        <StatCard
          title="Collected"
          value={animatedValues.collected}
          icon={CheckCircle}
          color="bg-gradient-success"
          subtitle={`${animatedValues.collectionRate}% collection rate`}
          trend={{ value: 15, isPositive: true }}
        />
        
        <StatCard
          title="Pending"
          value={animatedValues.pending}
          icon={Clock}
          color="bg-gradient-warning"
          subtitle="Upcoming payments"
          trend={{ value: 5, isPositive: true }}
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Payment Status Pie Chart */}
        <ModernCard variant="elevated" className="animate-slide-in-left" hover>
          <div className="p-6 space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-secondary rounded-xl flex items-center justify-center">
                <Target size={20} className="text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-800">Payment Status Overview</h3>
                <p className="text-sm text-gray-500">Current payment distribution</p>
              </div>
            </div>
            
            <div className="h-80">
              {pieData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={70}
                      outerRadius={110}
                      paddingAngle={3}
                      dataKey="value"
                      animationBegin={0}
                      animationDuration={1500}
                    >
                      {pieData.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={entry.color}
                          className="drop-shadow-lg"
                        />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: number) => [`$${value.toLocaleString()}`, 'Amount']}
                      contentStyle={{ 
                        borderRadius: '12px', 
                        border: 'none', 
                        boxShadow: '0 10px 25px -5px rgb(0 0 0 / 0.1)',
                        background: 'rgba(255, 255, 255, 0.95)',
                        backdropFilter: 'blur(10px)'
                      }}
                    />
                    <Legend 
                      verticalAlign="bottom" 
                      height={36}
                      formatter={(value, entry: any) => {
                        const payload = entry?.payload || entry;
                        const IconComp = payload?.icon || CheckCircle;
                        const color = payload?.color || entry?.color || '#6b7280';
                        return (
                          <span className="text-gray-700 font-medium flex items-center gap-2">
                            <IconComp size={14} style={{ color }} />
                            {value}
                          </span>
                        );
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-gray-400 space-y-4">
                  <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center">
                    <Target size={24} className="text-gray-400" />
                  </div>
                  <div className="text-center">
                    <p className="font-medium">No data available</p>
                    <p className="text-sm">Add some dues to see payment distribution</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </ModernCard>

        {/* Monthly Collection Bar Chart */}
        <ModernCard variant="elevated" className="animate-slide-in-right" hover>
          <div className="p-6 space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-accent rounded-xl flex items-center justify-center">
                <BarChart3 size={20} className="text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-800">Monthly Collection Trend</h3>
                <p className="text-sm text-gray-500">Collection vs Due amounts</p>
              </div>
            </div>
            
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <defs>
                    <linearGradient id="collectedGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#22c55e" stopOpacity={0.8}/>
                      <stop offset="100%" stopColor="#16a34a" stopOpacity={0.6}/>
                    </linearGradient>
                    <linearGradient id="dueGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.8}/>
                      <stop offset="100%" stopColor="#d97706" stopOpacity={0.6}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis 
                    dataKey="month" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: '#6b7280', fontSize: 12 }}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: '#6b7280', fontSize: 12 }}
                    tickFormatter={(value) => `$${value / 1000}k`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      borderRadius: '12px', 
                      border: 'none', 
                      boxShadow: '0 10px 25px -5px rgb(0 0 0 / 0.1)',
                      background: 'rgba(255, 255, 255, 0.95)',
                      backdropFilter: 'blur(10px)'
                    }}
                    formatter={(value: number) => [`$${value.toLocaleString()}`, '']}
                  />
                  <Legend />
                  <Bar 
                    dataKey="collected" 
                    fill="url(#collectedGradient)"
                    radius={[4, 4, 0, 0]}
                    name="Collected"
                  />
                  <Bar 
                    dataKey="due" 
                    fill="url(#dueGradient)"
                    radius={[4, 4, 0, 0]}
                    name="Due Amount"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </ModernCard>
      </div>

      {/* Quick Actions */}
      <ModernCard variant="elevated" className="animate-fade-in" hover>
        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-gradient-purple rounded-xl flex items-center justify-center">
              <Activity size={20} className="text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-800">Quick Actions</h3>
              <p className="text-sm text-gray-500">Manage your finances efficiently</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: DollarSign, title: 'Record Payment', color: 'bg-success-500', action: 'payment' },
              { icon: Users, title: 'Add Customer', color: 'bg-primary-500', action: 'customer' },
              { icon: Calendar, title: 'Schedule Due', color: 'bg-warning-500', action: 'schedule' },
              { icon: Activity, title: 'View Reports', color: 'bg-secondary-500', action: 'reports' },
            ].map((item, index) => (
              <button
                key={item.action}
                className="group p-4 rounded-xl bg-gray-50 hover:bg-white border border-gray-200 hover:border-gray-300 transition-all duration-200 hover:scale-105 hover:shadow-md"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className={`w-10 h-10 ${item.color} rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                  <item.icon size={18} className="text-white" />
                </div>
                <div className="text-sm font-medium text-gray-800 group-hover:text-gray-900">
                  {item.title}
                </div>
              </button>
            ))}
          </div>
        </div>
      </ModernCard>
    </div>
  );
};