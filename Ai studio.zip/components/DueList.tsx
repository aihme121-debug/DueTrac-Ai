import React, { useState, useEffect } from 'react';
import { DueWithCustomer, PaymentStatus } from '../types';
import { Calendar, DollarSign, User, AlertCircle, CheckCircle, Clock, Send, Trash2, Edit, FileText, History, Eye, CreditCard, TrendingUp, TrendingDown, MoreVertical, ArrowUpRight } from 'lucide-react';
import { ModernCard, ModernBadge, ModernButton, ModernProgress } from '../utils/uiComponents';
import { animationPresets } from '../utils/animations';

interface DueListProps {
  dues: DueWithCustomer[];
  onGenerateReminder: (due: DueWithCustomer) => void;
  onEdit: (due: DueWithCustomer) => void;
  onDelete: (id: string) => void;
  onMarkPaid: (id: string) => void;
  onViewDetails: (due: DueWithCustomer) => void;
  onAddPayment?: (due: DueWithCustomer) => void;
}

export const DueList: React.FC<DueListProps> = ({ dues, onGenerateReminder, onEdit, onDelete, onMarkPaid, onViewDetails, onAddPayment }) => {
  const [filter, setFilter] = useState<'ALL' | 'OVERDUE' | 'PENDING' | 'PAID'>('ALL');
  const [animatedDues, setAnimatedDues] = useState<DueWithCustomer[]>([]);
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  // Animate dues entry with enhanced timing
  useEffect(() => {
    if (dues.length > 0) {
      setAnimatedDues([]);
      dues.forEach((due, index) => {
        setTimeout(() => {
          setAnimatedDues(prev => [...prev, due]);
        }, index * 150);
      });
    } else {
      setAnimatedDues([]);
    }
  }, [dues]);

  const filteredDues = animatedDues.filter(due => {
    if (filter === 'ALL') return true;
    return due.status === filter;
  });

  const getStatusConfig = (status: PaymentStatus) => {
    switch (status) {
      case PaymentStatus.PAID: 
        return {
          variant: 'success' as const,
          icon: <CheckCircle size={16} />,
          gradient: true,
          label: 'Paid',
          gradientTone: 'success'
        };
      case PaymentStatus.OVERDUE: 
        return {
          variant: 'danger' as const,
          icon: <AlertCircle size={16} />,
          gradient: true,
          label: 'Overdue',
          gradientTone: 'danger'
        };
      case PaymentStatus.PARTIAL: 
        return {
          variant: 'accent' as const,
          icon: <TrendingUp size={16} />,
          gradient: true,
          label: 'Partial',
          gradientTone: 'accent'
        };
      default: 
        return {
          variant: 'warning' as const,
          icon: <Clock size={16} />,
          gradient: true,
          label: 'Pending',
          gradientTone: 'warning'
        };
    }
  };

  const getPriorityColor = (due: DueWithCustomer) => {
    const daysUntilDue = Math.ceil((new Date(due.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
    
    if (due.status === PaymentStatus.PAID) return 'bg-success-100 text-success-700 border-success-200 shadow-success-sm';
    if (daysUntilDue < 0) return 'bg-danger-100 text-danger-700 border-danger-200 shadow-danger-sm';
    if (daysUntilDue <= 3) return 'bg-warning-100 text-warning-700 border-warning-200 shadow-warning-sm';
    return 'bg-primary-100 text-primary-700 border-primary-200 shadow-primary-sm';
  };

  const getStatusGradient = (status: PaymentStatus) => {
    switch (status) {
      case PaymentStatus.PAID: return 'bg-gradient-success';
      case PaymentStatus.OVERDUE: return 'bg-gradient-danger';
      case PaymentStatus.PARTIAL: return 'bg-gradient-accent';
      default: return 'bg-gradient-warning';
    }
  };

  return (
    <ModernCard variant="elevated" className="overflow-hidden" glow>
      {/* Simplified Header */}
      <div className="bg-gradient-premium p-4 sm:p-6 text-white relative">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
          <div className="mb-4 sm:mb-0">
            <h2 className="text-2xl sm:text-3xl font-bold mb-1">
              Due Management
            </h2>
            <p className="text-white/80 text-sm sm:text-base">Track and manage all your pending payments</p>
          </div>
          <div className="text-right">
            <div className="text-2xl sm:text-3xl font-bold">
              ${dues.reduce((sum, due) => sum + due.amount, 0).toLocaleString()}
            </div>
            <div className="text-sm text-white/70">Total Outstanding</div>
          </div>
        </div>
        
        {/* Simplified Quick Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { 
              label: 'All', 
              value: dues.length, 
              color: 'bg-white/20'
            },
            { 
              label: 'Overdue', 
              value: dues.filter(d => d.status === PaymentStatus.OVERDUE).length, 
              color: 'bg-red-500/30'
            },
            { 
              label: 'Pending', 
              value: dues.filter(d => d.status === PaymentStatus.PENDING).length, 
              color: 'bg-yellow-500/30'
            },
            { 
              label: 'Paid', 
              value: dues.filter(d => d.status === PaymentStatus.PAID).length, 
              color: 'bg-green-500/30'
            }
          ].map((stat) => (
            <div 
              key={stat.label} 
              className={`${stat.color} rounded-xl p-3`}
            >
              <div className="text-xl sm:text-2xl font-bold text-white">
                {stat.value}
              </div>
              <div className="text-xs text-white/70">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Simplified Filter Tabs */}
      <div className="p-4 border-b border-gray-200 bg-gray-50">
        <div className="flex flex-wrap gap-2">
          {[
            { key: 'ALL', label: 'All Dues', icon: DollarSign, color: 'primary' },
            { key: 'OVERDUE', label: 'Overdue', icon: AlertCircle, color: 'danger' },
            { key: 'PENDING', label: 'Pending', icon: Clock, color: 'warning' },
            { key: 'PAID', label: 'Paid', icon: CheckCircle, color: 'success' }
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                filter === tab.key 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-100'
              }`}
            >
              <tab.icon size={16} />
              <span className="font-medium text-sm">{tab.label}</span>
              <span className={`px-2 py-1 rounded-full text-xs ${
                filter === tab.key ? 'bg-white/20' : 'bg-gray-100'
              }`}>
                {dues.filter(d => tab.key === 'ALL' ? true : d.status === tab.key).length}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Enhanced Due Cards List with Modern Styling */}
      <div className="bg-gradient-to-br from-gray-50 to-white p-6">
        {filteredDues.length === 0 ? (
          <ModernCard variant="elevated" className="text-center" padding="xl" glow>
            <div className="flex flex-col items-center space-y-6">
              <div className="w-24 h-24 bg-gradient-to-br from-gray-100 via-gray-200 to-gray-300 rounded-3xl flex items-center justify-center shadow-lg">
                <DollarSign size={40} className="text-gray-400 animate-pulse" />
              </div>
              <div className="space-y-3">
                <h3 className="text-xl font-bold text-gray-900">No dues found</h3>
                <p className="text-gray-500 text-lg">There are no dues in this category at the moment.</p>
                <div className="text-sm text-gray-400">Try selecting a different filter to see more results.</div>
              </div>
            </div>
          </ModernCard>
        ) : (
          <div className="grid gap-6">
            {filteredDues.map((due, index) => {
              const brokenPromise = due.lastPaymentAgreedDate && new Date(due.lastPaymentAgreedDate) < new Date() && due.status !== PaymentStatus.PAID;
              const daysUntilDue = Math.ceil((new Date(due.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
              const progressPercentage = Math.min((due.paidAmount / due.amount) * 100, 100);
              const statusConfig = getStatusConfig(due.status);
              const isHovered = hoveredCard === due.id;
              
              return (
                <ModernCard
                  key={due.id}
                  variant="elevated"
                  className={`animate-elegant-fade transition-all duration-500 ${
                    isHovered ? 'scale-[1.02] shadow-glow-primary' : 'hover:shadow-medium'
                  }`}
                  hover
                  glow
                  padding="none"
                  style={{ animationDelay: `${index * 150}ms` }}
                  onMouseEnter={() => setHoveredCard(due.id)}
                  onMouseLeave={() => setHoveredCard(null)}
                >
                  {/* Card Header with Gradient Background */}
                  <div className={`p-6 ${getStatusGradient(due.status)} text-white relative overflow-hidden`}>
                    {/* Floating particles effect */}
                    <span className="absolute top-4 right-4 w-1 h-1 bg-white/40 rounded-full animate-float" />
                    <span className="absolute bottom-6 left-6 w-1 h-1 bg-white/30 rounded-full animate-ping" style={{ animationDelay: '0.5s' }} />
                    
                    <div className="flex items-start justify-between mb-4 relative z-10">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <h3 className="text-xl font-bold text-white drop-shadow-lg">
                            {due.title}
                          </h3>
                          <ModernBadge
                            variant={statusConfig.variant}
                            gradient={true}
                            size="lg"
                            className="flex items-center gap-2 backdrop-blur-sm border border-white/20"
                          >
                            {statusConfig.icon}
                            {statusConfig.label}
                          </ModernBadge>
                          {brokenPromise && (
                            <ModernBadge variant="danger" gradient size="md" className="backdrop-blur-sm border border-white/20">
                              <AlertCircle size={14} />
                              Broken Promise
                            </ModernBadge>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-6 text-sm text-white/90">
                          <div className="flex items-center gap-3 bg-white/20 backdrop-blur-sm rounded-xl px-4 py-2">
                            <User size={16} className="text-white/80" />
                            <span className="font-semibold">{due.customer?.name || 'Unknown Customer'}</span>
                          </div>
                          <div className="flex items-center gap-3 bg-white/20 backdrop-blur-sm rounded-xl px-4 py-2">
                            <Calendar size={16} className="text-white/80" />
                            <span className={`font-semibold ${
                              daysUntilDue < 0 && due.status !== PaymentStatus.PAID ? 'text-yellow-200' : 'text-white'
                            }`}>
                              {daysUntilDue < 0 ? `${Math.abs(daysUntilDue)} days overdue` : `${daysUntilDue} days remaining`}
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      {/* Enhanced Amount Display */}
                      <div className="text-right space-y-2">
                        <div className="text-3xl font-bold text-white drop-shadow-lg">
                          ${due.amount.toLocaleString()}
                        </div>
                        {due.paidAmount > 0 && (
                          <div className="text-sm text-white/90 font-semibold bg-white/20 backdrop-blur-sm rounded-lg px-3 py-1">
                            Paid: ${due.paidAmount.toLocaleString()}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="p-6 space-y-6">
                    {/* Enhanced Progress Bar */}
                    {due.paidAmount > 0 && (
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-sm text-gray-600">
                          <span className="font-semibold">Payment Progress</span>
                          <span className="font-bold text-lg">{Math.round(progressPercentage)}%</span>
                        </div>
                        <ModernProgress
                          value={progressPercentage}
                          variant={progressPercentage === 100 ? 'success' : 'primary'}
                          gradient={true}
                          animated
                          height="lg"
                          className="rounded-full"
                        />
                      </div>
                    )}

                    {/* Enhanced Additional Info */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {due.lastPaymentDate && (
                        <div className="flex items-center gap-3 text-sm bg-gray-50 rounded-xl p-4 border border-gray-100">
                          <History size={16} className="text-primary-500" />
                          <div>
                            <div className="font-semibold text-gray-900">Last Payment</div>
                            <div className="text-gray-600">{new Date(due.lastPaymentDate).toLocaleDateString()}</div>
                          </div>
                        </div>
                      )}
                      
                      {due.lastPaymentAgreedDate && (
                        <div className={`flex items-center gap-3 text-sm rounded-xl p-4 border ${
                          brokenPromise 
                            ? 'bg-danger-50 border-danger-200 text-danger-700' 
                            : 'bg-gray-50 border-gray-100 text-gray-700'
                        }`}>
                          <Calendar size={16} className={brokenPromise ? 'text-danger-500' : 'text-primary-500'} />
                          <div>
                            <div className={`font-semibold ${brokenPromise ? 'text-danger-900' : 'text-gray-900'}`}>
                              {brokenPromise ? 'Broken Promise' : 'Promised Date'}
                            </div>
                            <div className={brokenPromise ? 'text-danger-600' : 'text-gray-600'}>
                              {new Date(due.lastPaymentAgreedDate).toLocaleDateString()}
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {due.shortNote && (
                        <div className="md:col-span-2 flex items-start gap-3 text-sm bg-gradient-to-r from-accent-50 to-primary-50 rounded-xl p-4 border border-accent-200">
                          <FileText size={16} className="text-accent-500 mt-1 shrink-0" />
                          <div>
                            <div className="font-semibold text-gray-900 mb-1">Note</div>
                            <span className="text-gray-700 italic leading-relaxed">{due.shortNote}</span>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Enhanced Payment History Preview */}
                    {due.paymentHistory && due.paymentHistory.length > 0 && (
                      <div className="bg-gradient-to-r from-success-50 to-primary-50 rounded-2xl p-6 border border-success-200">
                        <div className="flex items-center justify-between mb-4">
                          <h4 className="text-lg font-bold text-gray-900 flex items-center gap-3">
                            <div className="w-8 h-8 bg-success-500 rounded-xl flex items-center justify-center">
                              <History size={16} className="text-white" />
                            </div>
                            Recent Payments
                          </h4>
                          <ArrowUpRight size={20} className="text-success-500" />
                        </div>
                        <div className="space-y-3">
                          {due.paymentHistory.slice(-3).map((payment, idx) => (
                            <div key={idx} className="flex items-center justify-between text-sm bg-white rounded-xl p-4 shadow-sm">
                              <div className="flex items-center gap-3">
                                <div className="w-3 h-3 bg-success-500 rounded-full animate-pulse"></div>
                                <div>
                                  <div className="font-semibold text-gray-900">{new Date(payment.date).toLocaleDateString()}</div>
                                  {payment.note && <div className="text-gray-500 text-xs">{payment.note}</div>}
                                </div>
                              </div>
                              <span className="font-bold text-success-600 text-lg">+${payment.amount.toLocaleString()}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Enhanced Action Buttons */}
                    <div className="flex flex-wrap gap-3 pt-4 border-t border-gray-100" onClick={(e) => e.stopPropagation()}>
                      <ModernButton
                        onClick={() => onViewDetails(due)}
                        variant="secondary"
                        gradient={false}
                        size="lg"
                        className="flex items-center gap-3 px-6 py-3 rounded-2xl"
                      >
                        <Eye size={18} />
                        View Details
                      </ModernButton>
                      
                      {due.status !== PaymentStatus.PAID && (
                        <>
                          <ModernButton
                            onClick={() => onAddPayment && onAddPayment(due)}
                            variant="success"
                            gradient
                            gradientTransition
                            active
                            gradientTone="success"
                            size="lg"
                            className="flex items-center gap-3 px-6 py-3 rounded-2xl shadow-glow-success"
                          >
                            <CreditCard size={18} />
                            Add Payment
                          </ModernButton>
                          
                          <ModernButton
                            onClick={() => onGenerateReminder(due)}
                            variant="accent"
                            gradient
                            gradientTransition
                            active
                            gradientTone="accent"
                            size="lg"
                            className="flex items-center gap-3 px-6 py-3 rounded-2xl shadow-glow-accent"
                          >
                            <Send size={18} />
                            Send Reminder
                          </ModernButton>
                          
                          <ModernButton
                            onClick={() => onMarkPaid(due.id)}
                            variant="success"
                            gradient={false}
                            size="lg"
                            className="flex items-center gap-3 px-6 py-3 rounded-2xl"
                          >
                            <CheckCircle size={18} />
                            Mark Paid
                          </ModernButton>
                        </>
                      )}
                      
                      <div className="ml-auto flex gap-3">
                        <ModernButton
                          onClick={() => onEdit(due)}
                          variant="ghost"
                          size="lg"
                          className="flex items-center gap-3 px-6 py-3 rounded-2xl"
                        >
                          <Edit size={18} />
                          Edit
                        </ModernButton>
                        
                        <ModernButton
                          onClick={() => onDelete(due.id)}
                          variant="danger"
                          gradient={false}
                          size="lg"
                          className="flex items-center gap-3 px-6 py-3 rounded-2xl"
                        >
                          <Trash2 size={18} />
                          Delete
                        </ModernButton>
                      </div>
                    </div>
                  </div>
                </ModernCard>
              );
            })}
          </div>
        )}
      </div>
    </ModernCard>
  );
};