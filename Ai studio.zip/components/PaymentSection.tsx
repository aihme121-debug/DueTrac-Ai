import React, { useState, useMemo, useEffect } from 'react';
import { Customer, DueItem, PaymentTransaction } from '../types';
import { DollarSign, Calendar, User, Search, Filter, Download, Eye, Trash2, CreditCard, TrendingUp, TrendingDown, FileText, ArrowUpRight, PieChart, BarChart3 } from 'lucide-react';
import { ModernCard, ModernButton, ModernBadge, ModernInput } from '../utils/uiComponents';
import { animationPresets } from '../utils/animations';

interface PaymentSectionProps {
  payments: PaymentTransaction[];
  customers: Customer[];
  dues: DueItem[];
  onViewPaymentDetails?: (payment: PaymentTransaction) => void;
  onDeletePayment?: (paymentId: string) => void;
}

export const PaymentSection: React.FC<PaymentSectionProps> = ({
  payments,
  customers,
  dues,
  onViewPaymentDetails,
  onDeletePayment
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMethod, setFilterMethod] = useState<string>('ALL');
  const [dateFilter, setDateFilter] = useState<string>('ALL');
  const [animatedPayments, setAnimatedPayments] = useState<PaymentTransaction[]>([]);
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  // Animate payments entry with enhanced timing
  useEffect(() => {
    if (payments.length > 0) {
      setAnimatedPayments([]);
      payments.forEach((payment, index) => {
        setTimeout(() => {
          setAnimatedPayments(prev => [...prev, payment]);
        }, index * 100);
      });
    } else {
      setAnimatedPayments([]);
    }
  }, [payments]);

  // Create maps for efficient lookups
  const customerMap = useMemo(() => 
    new Map(customers.map(c => [c.id, c])), 
    [customers]
  );

  const dueMap = useMemo(() => 
    new Map(dues.map(d => [d.id, d])), 
    [dues]
  );

  // Filter payments
  const filteredPayments = useMemo(() => {
    let filtered = animatedPayments;

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(payment => {
        const customer = customerMap.get(payment.customerId);
        const due = dueMap.get(payment.dueId);
        const searchLower = searchTerm.toLowerCase();
        
        return (
          customer?.name.toLowerCase().includes(searchLower) ||
          customer?.email.toLowerCase().includes(searchLower) ||
          due?.title.toLowerCase().includes(searchLower) ||
          payment.paymentMethod.toLowerCase().includes(searchLower) ||
          payment.notes.toLowerCase().includes(searchLower)
        );
      });
    }

    // Payment method filter
    if (filterMethod !== 'ALL') {
      filtered = filtered.filter(payment => payment.paymentMethod === filterMethod);
    }

    // Date filter
    if (dateFilter !== 'ALL') {
      const now = new Date();
      const filterDate = new Date();
      
      switch (dateFilter) {
        case 'TODAY':
          filtered = filtered.filter(payment => 
            new Date(payment.paymentDate).toDateString() === now.toDateString()
          );
          break;
        case 'WEEK':
          filterDate.setDate(now.getDate() - 7);
          filtered = filtered.filter(payment => 
            new Date(payment.paymentDate) >= filterDate
          );
          break;
        case 'MONTH':
          filterDate.setMonth(now.getMonth() - 1);
          filtered = filtered.filter(payment => 
            new Date(payment.paymentDate) >= filterDate
          );
          break;
      }
    }

    // Sort by payment date (newest first)
    return filtered.sort((a, b) => 
      new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime()
    );
  }, [animatedPayments, searchTerm, filterMethod, dateFilter, customerMap, dueMap]);

  // Calculate totals
  const totals = useMemo(() => {
    const total = filteredPayments.reduce((sum, payment) => sum + payment.amount, 0);
    const cash = filteredPayments.filter(p => p.paymentMethod === 'cash').reduce((sum, payment) => sum + payment.amount, 0);
    const bank = filteredPayments.filter(p => p.paymentMethod === 'bank_transfer').reduce((sum, payment) => sum + payment.amount, 0);
    const card = filteredPayments.filter(p => p.paymentMethod === 'credit_card').reduce((sum, payment) => sum + payment.amount, 0);
    
    return { total, cash, bank, card };
  }, [filteredPayments]);

  const paymentMethods = ['cash', 'bank_transfer', 'credit_card', 'check', 'other'];

  const getPaymentMethodConfig = (method: string) => {
    switch (method) {
      case 'cash': return { icon: DollarSign, color: 'success', label: 'Cash', gradientTone: 'success' };
      case 'bank_transfer': return { icon: TrendingDown, color: 'accent', label: 'Bank Transfer', gradientTone: 'accent' };
      case 'credit_card': return { icon: CreditCard, color: 'primary', label: 'Credit Card', gradientTone: 'primary' };
      case 'check': return { icon: FileText, color: 'warning', label: 'Check', gradientTone: 'warning' };
      default: return { icon: DollarSign, color: 'neutral', label: 'Other', gradientTone: 'secondary' };
    }
  };

  const getPaymentMethodGradient = (method: string) => {
    switch (method) {
      case 'cash': return 'bg-gradient-success';
      case 'bank_transfer': return 'bg-gradient-accent';
      case 'credit_card': return 'bg-gradient-primary';
      case 'check': return 'bg-gradient-warning';
      default: return 'bg-gradient-secondary';
    }
  };

  const exportPayments = () => {
    const csvContent = [
      ['Date', 'Customer', 'Due Title', 'Amount', 'Method', 'Notes'],
      ...filteredPayments.map(payment => {
        const customer = customerMap.get(payment.customerId);
        const due = dueMap.get(payment.dueId);
        return [
          new Date(payment.paymentDate).toLocaleDateString(),
          customer?.name || 'Unknown',
          due?.title || 'Unknown',
          payment.amount.toFixed(2),
          payment.paymentMethod,
          payment.notes
        ];
      })
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `payments_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <ModernCard variant="elevated" className="overflow-hidden" glow>
      {/* Enhanced Header with Premium Gradient */}
      <div className="bg-gradient-luxury p-8 text-white relative overflow-hidden">
        {/* Floating particles effect */}
        <span className="absolute top-4 right-4 w-2 h-2 bg-white/30 rounded-full animate-float" />
        <span className="absolute bottom-6 left-6 w-1 h-1 bg-white/40 rounded-full animate-ping" style={{ animationDelay: '0.5s' }} />
        <span className="absolute top-8 left-8 w-1 h-1 bg-white/20 rounded-full animate-float" style={{ animationDelay: '1s' }} />
        
        <div className="flex items-center justify-between mb-6 relative z-10">
          <div className="flex items-center gap-6">
            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm border border-white/30 shadow-lg">
              <DollarSign size={32} className="text-white drop-shadow-lg" />
            </div>
            <div className="space-y-2">
              <h2 className="text-3xl font-bold mb-2 bg-gradient-to-r from-white to-white/90 bg-clip-text text-transparent">
                Payment Management
              </h2>
              <p className="text-white/80 text-lg">Track and manage all payment transactions</p>
            </div>
          </div>
          <ModernButton
            onClick={exportPayments}
            variant="secondary"
            gradient={false}
            size="lg"
            className="flex items-center gap-3 px-6 py-3 rounded-2xl backdrop-blur-sm"
          >
            <Download size={18} />
            Export CSV
          </ModernButton>
        </div>

        {/* Enhanced Summary Cards with Premium Styling */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
          <ModernCard variant="glass" padding="lg" className="text-center group hover:scale-105 transition-all duration-300" hover glow>
            <div className="space-y-3">
              <div className="text-sm text-white/70 font-medium mb-2">Total Payments</div>
              <div className="text-4xl font-bold text-white bg-gradient-primary bg-clip-text text-transparent">${totals.total.toFixed(2)}</div>
              <div className="text-xs text-white/60 font-medium">All transactions</div>
            </div>
          </ModernCard>
          
          <ModernCard variant="glass" padding="lg" className="text-center group hover:scale-105 transition-all duration-300" hover glow>
            <div className="space-y-3">
              <div className="text-sm text-white/70 font-medium mb-2">Cash Payments</div>
              <div className="text-4xl font-bold text-white bg-gradient-success bg-clip-text text-transparent">${totals.cash.toFixed(2)}</div>
              <div className="text-xs text-white/60 font-medium">Physical currency</div>
            </div>
          </ModernCard>
          
          <ModernCard variant="glass" padding="lg" className="text-center group hover:scale-105 transition-all duration-300" hover glow>
            <div className="space-y-3">
              <div className="text-sm text-white/70 font-medium mb-2">Bank Transfers</div>
              <div className="text-4xl font-bold text-white bg-gradient-accent bg-clip-text text-transparent">${totals.bank.toFixed(2)}</div>
              <div className="text-xs text-white/60 font-medium">Electronic transfers</div>
            </div>
          </ModernCard>
          
          <ModernCard variant="glass" padding="lg" className="text-center group hover:scale-105 transition-all duration-300" hover glow>
            <div className="space-y-3">
              <div className="text-sm text-white/70 font-medium mb-2">Card Payments</div>
              <div className="text-4xl font-bold text-white bg-gradient-warning bg-clip-text text-transparent">${totals.card.toFixed(2)}</div>
              <div className="text-xs text-white/60 font-medium">Credit/debit cards</div>
            </div>
          </ModernCard>
        </div>
      </div>

      {/* Enhanced Modern Filters */}
      <div className="p-8 border-b border-gray-100/50 bg-gradient-to-r from-gray-50 to-white">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="flex-1">
            <ModernInput
              icon={<Search size={18} className="text-gray-400" />}
              placeholder="Search payments by customer, due title, or notes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              variant="outlined"
              size="lg"
              className="rounded-2xl"
            />
          </div>
          <div className="flex flex-wrap gap-3">
            <ModernButton
              variant={filterMethod === 'ALL' ? 'primary' : 'ghost'}
              gradient={filterMethod === 'ALL'}
              gradientTransition
              active={filterMethod === 'ALL'}
              gradientTone="primary"
              size="lg"
              onClick={() => setFilterMethod('ALL')}
              className={`px-6 py-3 rounded-2xl ${
                filterMethod === 'ALL' ? 'shadow-glow-primary animate-breathe' : 'hover:shadow-medium'
              }`}
            >
              All Methods
            </ModernButton>
            {paymentMethods.map(method => {
              const config = getPaymentMethodConfig(method);
              return (
                <ModernButton
                  key={method}
                  variant={filterMethod === method ? config.color as any : 'ghost'}
                  gradient={filterMethod === method}
                  gradientTransition
                  active={filterMethod === method}
                  gradientTone={config.gradientTone}
                  size="lg"
                  onClick={() => setFilterMethod(method)}
                  className={`flex items-center gap-3 px-6 py-3 rounded-2xl ${
                    filterMethod === method ? `shadow-glow-${config.gradientTone} animate-breathe` : 'hover:shadow-medium'
                  }`}
                >
                  <config.icon size={18} />
                  {config.label}
                </ModernButton>
              );
            })}
          </div>
        </div>
        
        {/* Enhanced Date Filter Buttons */}
        <div className="flex flex-wrap gap-3 mt-6">
          {[
            { key: 'ALL', label: 'All Time', icon: Calendar },
            { key: 'TODAY', label: 'Today', icon: Calendar },
            { key: 'WEEK', label: 'This Week', icon: Calendar },
            { key: 'MONTH', label: 'This Month', icon: Calendar }
          ].map((filter) => (
            <ModernButton
              key={filter.key}
              variant={dateFilter === filter.key ? 'accent' : 'ghost'}
              gradient={dateFilter === filter.key}
              gradientTransition
              active={dateFilter === filter.key}
              gradientTone="accent"
              size="md"
              onClick={() => setDateFilter(filter.key)}
              className={`flex items-center gap-3 px-5 py-2 rounded-2xl ${
                dateFilter === filter.key ? 'shadow-glow-accent animate-breathe' : 'hover:shadow-medium'
              }`}
            >
              <filter.icon size={16} />
              {filter.label}
            </ModernButton>
          ))}
        </div>
      </div>

      {/* Enhanced Payments Grid */}
      <div className="bg-gradient-to-br from-gray-50 to-white p-8">
        {filteredPayments.length === 0 ? (
          <ModernCard variant="elevated" className="text-center" padding="xl" glow>
            <div className="flex flex-col items-center space-y-6">
              <div className="w-24 h-24 bg-gradient-to-br from-gray-100 via-gray-200 to-gray-300 rounded-3xl flex items-center justify-center shadow-lg">
                <DollarSign size={40} className="text-gray-400 animate-pulse" />
              </div>
              <div className="space-y-3">
                <h3 className="text-xl font-bold text-gray-900">No payments found</h3>
                <p className="text-gray-500 text-lg">No payments match your current filters.</p>
                <div className="text-sm text-gray-400">Try adjusting your search or filter criteria.</div>
              </div>
            </div>
          </ModernCard>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredPayments.map((payment, index) => {
              const customer = customerMap.get(payment.customerId);
              const due = dueMap.get(payment.dueId);
              const methodConfig = getPaymentMethodConfig(payment.paymentMethod);
              const isHovered = hoveredCard === payment.id;
              
              return (
                <ModernCard
                  key={payment.id}
                  variant="elevated"
                  className={`animate-elegant-fade transition-all duration-500 ${
                    isHovered ? 'scale-[1.02] shadow-glow-primary' : 'hover:shadow-medium'
                  }`}
                  hover
                  glow
                  padding="lg"
                  style={{ animationDelay: `${index * 100}ms` }}
                  onMouseEnter={() => setHoveredCard(payment.id)}
                  onMouseLeave={() => setHoveredCard(null)}
                >
                  {/* Enhanced Payment Card Header */}
                  <div className={`p-6 ${getPaymentMethodGradient(payment.paymentMethod)} text-white rounded-2xl mb-6 relative overflow-hidden`}>
                    {/* Floating particles effect */}
                    <span className="absolute top-4 right-4 w-1 h-1 bg-white/40 rounded-full animate-float" />
                    <span className="absolute bottom-6 left-6 w-1 h-1 bg-white/30 rounded-full animate-ping" style={{ animationDelay: '0.5s' }} />
                    
                    <div className="flex items-start justify-between relative z-10">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center border border-white/30 shadow-lg">
                          <methodConfig.icon size={24} className="text-white drop-shadow-lg" />
                        </div>
                        <div className="space-y-1">
                          <div className="font-bold text-white text-xl drop-shadow-lg">{customer?.name || 'Unknown Customer'}</div>
                          <div className="text-white/80 text-sm">{due?.title || 'Unknown Due'}</div>
                        </div>
                      </div>
                      <ModernBadge
                        variant={methodConfig.color as any}
                        gradient
                        size="md"
                        className="backdrop-blur-sm border border-white/20"
                      >
                        {methodConfig.label}
                      </ModernBadge>
                    </div>
                  </div>
                  
                  {/* Enhanced Payment Amount */}
                  <div className="text-center mb-6">
                    <div className="text-4xl font-bold text-gray-900 mb-2">${payment.amount.toFixed(2)}</div>
                    <div className="text-lg text-gray-600 font-medium">
                      {new Date(payment.paymentDate).toLocaleDateString('en-US', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </div>
                  </div>
                  
                  {/* Enhanced Payment Details */}
                  {payment.notes && (
                    <div className="mb-6 p-4 bg-gradient-to-r from-accent-50 to-primary-50 rounded-2xl border border-accent-200">
                      <div className="flex items-center gap-2 mb-2">
                        <FileText size={16} className="text-accent-500" />
                        <div className="text-sm font-semibold text-gray-900">Notes</div>
                      </div>
                      <div className="text-gray-700 italic leading-relaxed">{payment.notes}</div>
                    </div>
                  )}
                  
                  {/* Enhanced Action Buttons */}
                  <div className="flex gap-3">
                    {onViewPaymentDetails && (
                      <ModernButton
                        onClick={() => onViewPaymentDetails(payment)}
                        variant="secondary"
                        gradient={false}
                        size="lg"
                        className="flex-1 flex items-center justify-center gap-3 px-6 py-3 rounded-2xl"
                      >
                        <Eye size={18} />
                        View Details
                      </ModernButton>
                    )}
                    {onDeletePayment && (
                      <ModernButton
                        onClick={() => onDeletePayment(payment.id)}
                        variant="danger"
                        gradient={false}
                        size="lg"
                        className="flex items-center justify-center gap-3 px-6 py-3 rounded-2xl"
                      >
                        <Trash2 size={18} />
                        Delete
                      </ModernButton>
                    )}
                  </div>
                </ModernCard>
              );
            })}
          </div>
        )}
      </div>

      {/* Enhanced Footer */}
      <div className="p-8 border-t border-gray-100/50 bg-gradient-to-r from-gray-50 to-white">
        <div className="flex items-center justify-between">
          <div className="text-lg text-gray-600">
            Showing <span className="font-bold text-gray-900">{filteredPayments.length}</span> of 
            <span className="font-bold text-gray-900">{payments.length}</span> payments
          </div>
          <div className="text-2xl font-bold text-gray-900 bg-gradient-primary bg-clip-text text-transparent">
            Total: ${totals.total.toFixed(2)}
          </div>
        </div>
      </div>
    </ModernCard>
  );
};