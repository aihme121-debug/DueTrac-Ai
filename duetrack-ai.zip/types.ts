export enum PaymentStatus {
  PENDING = 'PENDING',
  OVERDUE = 'OVERDUE',
  PAID = 'PAID',
  PARTIAL = 'PARTIAL'
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  notes?: string;
}

export interface PaymentRecord {
  id: string;
  date: string; // ISO Date String
  amount: number;
  note?: string;
}

export interface PromiseRecord {
  id: string;
  promisedDate: string; // The date they promised to pay
  createdAt: string; // When this promise was recorded
  status: 'PENDING' | 'BROKEN' | 'KEPT';
  note?: string;
}

export interface DueItem {
  id: string;
  customerId: string;
  amount: number;
  paidAmount: number;
  dueDate: string; // ISO Date String (Next Payment Date)
  title: string;
  status: PaymentStatus;
  createdAt: string;
  
  // New Fields
  shortNote?: string;
  lastPaymentDate?: string; // ISO Date String
  lastPaymentAgreedDate?: string; // ISO Date String (The date they promised but might have missed)
  paymentHistory?: PaymentRecord[];
  promiseHistory?: PromiseRecord[]; // Track history of all promises
}

export interface DueWithCustomer extends DueItem {
  customer: Customer;
}

export interface DashboardStats {
  totalDue: number;
  totalCollected: number;
  overdueCount: number;
  upcomingCount: number;
}