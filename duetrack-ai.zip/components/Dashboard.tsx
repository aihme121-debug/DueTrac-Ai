import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { DueItem, PaymentStatus } from '../types';
import { TrendingUp, AlertTriangle, CheckCircle, Clock } from 'lucide-react';

interface DashboardProps {
  dues: DueItem[];
}

export const Dashboard: React.FC<DashboardProps> = ({ dues }) => {
  const totalDue = dues.reduce((acc, curr) => acc + curr.amount, 0);
  const paid = dues.filter(d => d.status === PaymentStatus.PAID).reduce((acc, curr) => acc + curr.amount, 0);
  const overdue = dues.filter(d => d.status === PaymentStatus.OVERDUE).reduce((acc, curr) => acc + (curr.amount - curr.paidAmount), 0);
  const pending = dues.filter(d => d.status === PaymentStatus.PENDING).reduce((acc, curr) => acc + (curr.amount - curr.paidAmount), 0);
  
  const collectionRate = totalDue > 0 ? Math.round((paid / totalDue) * 100) : 0;

  const data = [
    { name: 'Paid', value: paid, color: '#10B981' },
    { name: 'Overdue', value: overdue, color: '#EF4444' },
    { name: 'Pending', value: pending, color: '#F59E0B' },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1 */}
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col">
          <span className="text-gray-500 text-xs font-medium uppercase tracking-wider mb-1">Total Outstanding</span>
          <div className="text-2xl font-bold text-gray-900">${(overdue + pending).toLocaleString()}</div>
          <div className="mt-auto pt-2 flex items-center text-xs text-blue-600 gap-1">
            <TrendingUp size={12} />
            <span>Track actively</span>
          </div>
        </div>

        {/* Card 2 */}
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col">
          <span className="text-gray-500 text-xs font-medium uppercase tracking-wider mb-1">Overdue</span>
          <div className="text-2xl font-bold text-red-600">${overdue.toLocaleString()}</div>
          <div className="mt-auto pt-2 flex items-center text-xs text-red-500 gap-1">
            <AlertTriangle size={12} />
            <span>Needs attention</span>
          </div>
        </div>

        {/* Card 3 */}
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col">
          <span className="text-gray-500 text-xs font-medium uppercase tracking-wider mb-1">Collected</span>
          <div className="text-2xl font-bold text-green-600">${paid.toLocaleString()}</div>
          <div className="mt-auto pt-2 flex items-center text-xs text-green-500 gap-1">
            <CheckCircle size={12} />
            <span>{collectionRate}% rate</span>
          </div>
        </div>

         {/* Card 4 */}
         <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col">
          <span className="text-gray-500 text-xs font-medium uppercase tracking-wider mb-1">Pending</span>
          <div className="text-2xl font-bold text-yellow-600">${pending.toLocaleString()}</div>
          <div className="mt-auto pt-2 flex items-center text-xs text-yellow-600 gap-1">
            <Clock size={12} />
            <span>Upcoming</span>
          </div>
        </div>
      </div>

      {/* Chart Section */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Payment Status Overview</h3>
        <div className="h-64 w-full">
            {data.length > 0 ? (
                 <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                   <Pie
                     data={data}
                     cx="50%"
                     cy="50%"
                     innerRadius={60}
                     outerRadius={80}
                     paddingAngle={5}
                     dataKey="value"
                   >
                     {data.map((entry, index) => (
                       <Cell key={`cell-${index}`} fill={entry.color} />
                     ))}
                   </Pie>
                   <Tooltip 
                     formatter={(value: number) => [`$${value.toLocaleString()}`, 'Amount']}
                     contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                   />
                   <Legend verticalAlign="bottom" height={36}/>
                 </PieChart>
               </ResponsiveContainer>
            ) : (
                <div className="h-full flex items-center justify-center text-gray-400">
                    No data available to display chart.
                </div>
            )}
        </div>
      </div>
    </div>
  );
};