import React, { useState } from 'react';
import { DueWithCustomer, PaymentStatus } from '../types';
import { Calendar, DollarSign, User, AlertCircle, CheckCircle, Clock, Send, Trash2, Edit, FileText, History, Eye } from 'lucide-react';

interface DueListProps {
  dues: DueWithCustomer[];
  onGenerateReminder: (due: DueWithCustomer) => void;
  onEdit: (due: DueWithCustomer) => void;
  onDelete: (id: string) => void;
  onMarkPaid: (id: string) => void;
  onViewDetails: (due: DueWithCustomer) => void; 
}

export const DueList: React.FC<DueListProps> = ({ dues, onGenerateReminder, onEdit, onDelete, onMarkPaid, onViewDetails }) => {
  const [filter, setFilter] = useState<'ALL' | 'OVERDUE' | 'PENDING' | 'PAID'>('ALL');

  const filteredDues = dues.filter(due => {
    if (filter === 'ALL') return true;
    return due.status === filter;
  });

  const getStatusColor = (status: PaymentStatus) => {
    switch (status) {
      case PaymentStatus.PAID: return 'bg-green-100 text-green-700 border-green-200';
      case PaymentStatus.OVERDUE: return 'bg-red-100 text-red-700 border-red-200';
      case PaymentStatus.PARTIAL: return 'bg-blue-100 text-blue-700 border-blue-200';
      default: return 'bg-yellow-100 text-yellow-700 border-yellow-200';
    }
  };

  const getStatusIcon = (status: PaymentStatus) => {
    switch (status) {
      case PaymentStatus.PAID: return <CheckCircle size={14} />;
      case PaymentStatus.OVERDUE: return <AlertCircle size={14} />;
      default: return <Clock size={14} />;
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      {/* Filters */}
      <div className="flex overflow-x-auto p-4 gap-2 border-b border-gray-100 no-scrollbar">
        {['ALL', 'OVERDUE', 'PENDING', 'PAID'].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f as any)}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              filter === f 
                ? 'bg-primary text-white shadow-md shadow-indigo-200' 
                : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
            }`}
          >
            {f.charAt(0) + f.slice(1).toLowerCase()}
          </button>
        ))}
      </div>

      {/* List */}
      <div className="divide-y divide-gray-100">
        {filteredDues.length === 0 ? (
          <div className="p-12 text-center text-gray-400 flex flex-col items-center">
            <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-4">
              <DollarSign size={24} className="opacity-30" />
            </div>
            <p>No dues found in this category.</p>
          </div>
        ) : (
          filteredDues.map((due) => {
             // Logic to check if a promise was broken
             const brokenPromise = due.lastPaymentAgreedDate && new Date(due.lastPaymentAgreedDate) < new Date() && due.status !== PaymentStatus.PAID;
             
             return (
              <div 
                key={due.id} 
                className="p-4 hover:bg-gray-50 transition-colors group cursor-pointer relative"
                onClick={() => onViewDetails(due)} // Whole card is clickable
              >
                <div className="flex flex-col gap-4">
                  
                  {/* Top Row: Title, Status, Amount */}
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-gray-900 text-lg group-hover:text-primary transition-colors">{due.title}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <span className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border ${getStatusColor(due.status)}`}>
                          {getStatusIcon(due.status)}
                          {due.status}
                        </span>
                        {brokenPromise && (
                          <span className="text-xs bg-red-50 text-red-600 px-2 py-0.5 rounded-full border border-red-100 font-medium">
                            Missed Promise: {new Date(due.lastPaymentAgreedDate!).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                       <div className="text-xl font-bold text-gray-900">${due.amount.toLocaleString()}</div>
                       {due.paidAmount > 0 && (
                          <div className="text-xs text-green-600 font-medium">Paid: ${due.paidAmount.toLocaleString()}</div>
                       )}
                    </div>
                  </div>

                  {/* Middle Row: Details (Customer, Dates, Notes) */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 gap-x-4 text-sm text-gray-600 bg-gray-50/50 p-3 rounded-lg border border-gray-100">
                    <div className="flex items-center gap-2">
                       <User size={14} className="text-gray-400" />
                       <span className="font-medium text-gray-700">{due.customer?.name || 'Unknown Customer'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                       <Calendar size={14} className="text-gray-400" />
                       <span className={new Date(due.dueDate) < new Date() && due.status !== 'PAID' ? 'text-red-600 font-medium' : ''}>
                         Next Due: {new Date(due.dueDate).toLocaleDateString()}
                       </span>
                    </div>
                    {due.lastPaymentDate && (
                      <div className="flex items-center gap-2 text-xs">
                        <History size={14} className="text-gray-400" />
                        <span>Last Payment: {new Date(due.lastPaymentDate).toLocaleDateString()}</span>
                      </div>
                    )}
                    {due.shortNote && (
                      <div className="col-span-1 sm:col-span-2 flex items-start gap-2 mt-1 pt-2 border-t border-gray-200/50">
                        <FileText size={14} className="text-gray-400 mt-0.5 shrink-0" />
                        <span className="italic text-gray-500 text-xs truncate">{due.shortNote}</span>
                      </div>
                    )}
                  </div>

                  {/* Payment History Preview (Only if exists) */}
                  {due.paymentHistory && due.paymentHistory.length > 0 && (
                    <div className="mt-1">
                      <div className="flex items-center gap-2 mb-1 px-1">
                        <History size={12} className="text-gray-400" />
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Latest Payment</span>
                      </div>
                      <div className="bg-gray-50/50 rounded p-1.5 flex items-center gap-2 text-xs border border-gray-100">
                           <div className="w-1.5 h-1.5 rounded-full bg-green-400"></div>
                           <span className="text-gray-600">{new Date(due.paymentHistory[due.paymentHistory.length -1].date).toLocaleDateString()}</span>
                           <span className="font-mono font-semibold text-green-600 ml-auto">+${due.paymentHistory[due.paymentHistory.length -1].amount}</span>
                      </div>
                    </div>
                  )}

                  {/* Bottom Row: Actions - Prevent Bubble Up */}
                  <div className="flex justify-end gap-2 pt-2" onClick={(e) => e.stopPropagation()}>
                      {due.status !== 'PAID' && (
                        <button 
                          onClick={() => onGenerateReminder(due)}
                          className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition" 
                        >
                          <Send size={14} /> Reminder
                        </button>
                      )}
                      
                      <button 
                        onClick={() => onViewDetails(due)}
                        className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition"
                        title="View Full Details"
                      >
                        <Eye size={16} />
                      </button>

                      <button 
                        onClick={() => onEdit(due)}
                        className="p-1.5 text-gray-500 hover:bg-gray-100 rounded-lg transition"
                        title="Edit"
                      >
                        <Edit size={16} />
                      </button>
                      
                      {due.status !== 'PAID' && (
                        <button 
                          onClick={() => onMarkPaid(due.id)}
                          className="p-1.5 text-green-600 hover:bg-green-50 rounded-lg transition"
                          title="Mark Paid"
                        >
                          <CheckCircle size={16} />
                        </button>
                      )}
                      
                      <button 
                        onClick={() => onDelete(due.id)}
                        className="p-1.5 text-red-400 hover:bg-red-50 rounded-lg transition"
                        title="Delete"
                      >
                        <Trash2 size={16} />
                      </button>
                  </div>

                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};