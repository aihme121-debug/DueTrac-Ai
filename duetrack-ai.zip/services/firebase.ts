import { initializeApp } from "firebase/app";
import { getFirestore, Firestore } from "firebase/firestore";

// Configuration provided by user
const firebaseConfig = {
  apiKey: "AIzaSyA4LFmYUK34TEMlK7o-SCPBdgZpNyZ8KJ8",
  authDomain: "dueall-27bff.firebaseapp.com",
  projectId: "dueall-27bff",
  storageBucket: "dueall-27bff.firebasestorage.app",
  messagingSenderId: "132561668068",
  appId: "1:132561668068:web:fae6325cb5c9d8e71569f1",
  measurementId: "G-0NGHKE44YD"
};

let db: Firestore | null = null;
let initError: string | null = null;
let isConfigured = false;

try {
  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  // Initialize Cloud Firestore and get a reference to the service
  db = getFirestore(app);
  isConfigured = true;
  console.log("Firebase initialized successfully");
} catch (error: any) {
  console.error("Firebase Initialization Error:", error);
  initError = error.message;
}

export { db, initError, isConfigured };