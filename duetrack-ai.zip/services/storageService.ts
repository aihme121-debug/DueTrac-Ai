import { db, isConfigured } from './firebase';
import { collection, getDocs, doc, setDoc, deleteDoc, writeBatch } from 'firebase/firestore';
import { Customer, DueItem, PaymentStatus } from '../types';

const CUSTOMERS_COL = 'customers';
const DUES_COL = 'dues';
const LS_CUSTOMERS_KEY = 'duetrack_customers_backup';
const LS_DUES_KEY = 'duetrack_dues_backup';

// --- Local Storage Helpers (Fallback) ---
const getLocalCustomers = (): Customer[] => {
  const data = localStorage.getItem(LS_CUSTOMERS_KEY);
  return data ? JSON.parse(data) : [];
}

const saveLocalCustomers = (customers: Customer[]) => {
  localStorage.setItem(LS_CUSTOMERS_KEY, JSON.stringify(customers));
}

const getLocalDues = (): DueItem[] => {
  const data = localStorage.getItem(LS_DUES_KEY);
  return data ? JSON.parse(data) : [];
}

const saveLocalDues = (dues: DueItem[]) => {
  localStorage.setItem(LS_DUES_KEY, JSON.stringify(dues));
}

// --- Seeding Logic (Works for both) ---
const seedDataIfNeeded = async () => {
  // Define Seed Data
  const customersSeed: Customer[] = [
      { id: 'c1', name: 'Acme Corp', phone: '555-0101', email: 'billing@acme.com', notes: 'Major enterprise client' },
      { id: 'c2', name: 'John Doe', phone: '555-0202', email: 'john@example.com', notes: 'Freelancer' },
      { id: 'c3', name: 'Sarah Smith', phone: '555-0303', email: 'sarah@design.co' },
  ];
  
  const today = new Date();
  const yesterday = new Date(today); yesterday.setDate(today.getDate() - 1);
  const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1);
  const nextWeek = new Date(today); nextWeek.setDate(today.getDate() + 7);
  const lastMonth = new Date(today); lastMonth.setMonth(today.getMonth() - 1);
  const twoMonthsAgo = new Date(today); twoMonthsAgo.setMonth(today.getMonth() - 2);

  const duesSeed: DueItem[] = [
      { 
        id: 'd1', customerId: 'c1', amount: 1500, paidAmount: 500, 
        dueDate: nextWeek.toISOString(), title: 'Web Development Invoice #101', 
        status: PaymentStatus.PARTIAL, createdAt: twoMonthsAgo.toISOString(),
        shortNote: 'Client requested extended timeline due to funding delay.',
        lastPaymentDate: lastMonth.toISOString(),
        paymentHistory: [
          { id: 'p1', date: lastMonth.toISOString(), amount: 500, note: 'Initial installment' }
        ],
        promiseHistory: [
          { id: 'pr1', promisedDate: lastMonth.toISOString(), createdAt: twoMonthsAgo.toISOString(), status: 'KEPT', note: 'Promised first installment' },
          { id: 'pr2', promisedDate: nextWeek.toISOString(), createdAt: lastMonth.toISOString(), status: 'PENDING', note: 'Promised remaining balance' }
        ]
      },
      { 
        id: 'd2', customerId: 'c2', amount: 50, paidAmount: 0, 
        dueDate: yesterday.toISOString(), title: 'Pizza Reimbursement', 
        status: PaymentStatus.OVERDUE, createdAt: lastMonth.toISOString(),
        shortNote: 'Promised to pay last Friday but missed it. Recurring issue.',
        lastPaymentAgreedDate: yesterday.toISOString(),
        promiseHistory: [
          { id: 'pr3', promisedDate: yesterday.toISOString(), createdAt: lastMonth.toISOString(), status: 'BROKEN', note: 'Said he would venmo me' }
        ]
      },
      { 
        id: 'd3', customerId: 'c3', amount: 300, paidAmount: 300, 
        dueDate: tomorrow.toISOString(), title: 'Logo Design', 
        status: PaymentStatus.PAID, createdAt: twoMonthsAgo.toISOString(),
        paymentHistory: [
           { id: 'p2', date: twoMonthsAgo.toISOString(), amount: 100 },
           { id: 'p3', date: yesterday.toISOString(), amount: 200 }
        ]
      },
  ];

  if (isConfigured && db) {
    // Firebase Seeding
    try {
      const customersSnapshot = await getDocs(collection(db, CUSTOMERS_COL));
      if (!customersSnapshot.empty) return;

      console.log("Seeding Database (Firebase)...");
      const batch = writeBatch(db);

      customersSeed.forEach(c => batch.set(doc(db!, CUSTOMERS_COL, c.id), c));
      duesSeed.forEach(d => batch.set(doc(db!, DUES_COL, d.id), d));

      await batch.commit();
    } catch (e) {
      console.error("Error seeding Firebase:", e);
    }
  } else {
    // LocalStorage Seeding
    const existing = getLocalCustomers();
    if (existing.length === 0) {
      console.log("Seeding Database (Local)...");
      saveLocalCustomers(customersSeed);
      saveLocalDues(duesSeed);
    }
  }
};


export const StorageService = {
  getCustomers: async (): Promise<Customer[]> => {
    await seedDataIfNeeded();
    
    if (isConfigured && db) {
      const snapshot = await getDocs(collection(db, CUSTOMERS_COL));
      return snapshot.docs.map(doc => doc.data() as Customer);
    } else {
      // Fallback
      return Promise.resolve(getLocalCustomers());
    }
  },

  saveCustomer: async (customer: Customer): Promise<void> => {
    if (isConfigured && db) {
      await setDoc(doc(db, CUSTOMERS_COL, customer.id), customer, { merge: true });
    } else {
      // Fallback
      const customers = getLocalCustomers();
      const index = customers.findIndex(c => c.id === customer.id);
      if (index >= 0) customers[index] = customer;
      else customers.push(customer);
      saveLocalCustomers(customers);
      return Promise.resolve();
    }
  },

  getDues: async (): Promise<DueItem[]> => {
    await seedDataIfNeeded();
    
    if (isConfigured && db) {
      const snapshot = await getDocs(collection(db, DUES_COL));
      return snapshot.docs.map(doc => doc.data() as DueItem);
    } else {
       // Fallback
       return Promise.resolve(getLocalDues());
    }
  },

  saveDue: async (due: DueItem): Promise<void> => {
    if (isConfigured && db) {
      await setDoc(doc(db, DUES_COL, due.id), due, { merge: true });
    } else {
       // Fallback
       const dues = getLocalDues();
       const index = dues.findIndex(d => d.id === due.id);
       if (index >= 0) dues[index] = due;
       else dues.push(due);
       saveLocalDues(dues);
       return Promise.resolve();
    }
  },

  deleteDue: async (id: string): Promise<void> => {
    if (isConfigured && db) {
      await deleteDoc(doc(db, DUES_COL, id));
    } else {
      // Fallback
      const dues = getLocalDues().filter(d => d.id !== id);
      saveLocalDues(dues);
      return Promise.resolve();
    }
  },

  getDuesWithCustomers: async (): Promise<(DueItem & { customer: Customer | undefined })[]> => {
    // We can reuse the getDues and getCustomers methods which handle the split logic
    const [dues, customers] = await Promise.all([
      StorageService.getDues(),
      StorageService.getCustomers()
    ]);

    const customerMap = new Map(customers.map(c => [c.id, c]));

    // Check for status updates based on date (e.g., auto-mark overdue)
    // We only update if necessary to avoid write loops
    const updates: Promise<void>[] = [];
    
    const updatedDues = dues.map(due => {
      const isOverdue = new Date(due.dueDate) < new Date() && due.paidAmount < due.amount;
      if (isOverdue && due.status !== PaymentStatus.PAID && due.status !== PaymentStatus.OVERDUE) {
        const updatedDue = { ...due, status: PaymentStatus.OVERDUE };
        updates.push(StorageService.saveDue(updatedDue));
        return updatedDue;
      }
      return due;
    });

    // Fire and forget updates
    if (updates.length > 0) {
      Promise.all(updates).catch(console.error);
    }

    return updatedDues.map(due => ({
      ...due,
      customer: customerMap.get(due.customerId)
    })).sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
  }
};