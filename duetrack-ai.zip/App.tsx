import React, { useState, useEffect } from 'react';
import { Dashboard } from './components/Dashboard';
import { DueList } from './components/DueList';
import { SmartAddModal } from './components/SmartAddModal';
import { DueDetailModal } from './components/DueDetailModal';
import { StorageService } from './services/storageService';
import { isConfigured } from './services/firebase';
import { DueWithCustomer, PaymentStatus, DueItem, Customer, PromiseRecord } from './types';
import { GeminiService } from './services/geminiService';
import { LayoutGrid, List, Plus, Bell, MessageSquare, Loader2, Database, WifiOff } from 'lucide-react';

const App = () => {
  const [dues, setDues] = useState<DueWithCustomer[]>([]);
  const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'LIST'>('DASHBOARD');
  const [isLoading, setIsLoading] = useState(true);
  
  // Modal States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingDue, setEditingDue] = useState<DueWithCustomer | null>(null);
  
  // Detail Modal State
  const [viewingDue, setViewingDue] = useState<DueWithCustomer | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  // Reminder State
  const [reminderModalOpen, setReminderModalOpen] = useState(false);
  const [reminderText, setReminderText] = useState('');
  const [reminderLoading, setReminderLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const data = await StorageService.getDuesWithCustomers();
      setDues(data);
    } catch (error: any) {
      console.error("Failed to load data:", error);
      alert("Failed to load data. Please refresh.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveDue = async (formData: any) => {
    if (!formData.customerName || !formData.amount || !formData.title) return;

    setIsLoading(true);

    try {
        // Find or Create Customer
        let customerId = '';
        const customers = await StorageService.getCustomers();
        const existingCustomer = customers.find(c => c.name.toLowerCase() === formData.customerName.toLowerCase());
        
        if (existingCustomer) {
          customerId = existingCustomer.id;
        } else {
          const newCustomer: Customer = {
            id: `c_${Date.now()}`,
            name: formData.customerName,
            email: '',
            phone: ''
          };
          await StorageService.saveCustomer(newCustomer);
          customerId = newCustomer.id;
        }

        // Logic to handle Promise History
        let promiseHistory = editingDue?.promiseHistory || [];
        const newAgreedDate = formData.lastPaymentAgreedDate;
        
        // If a new agreed date is set and it's different from the old one, add to history
        if (newAgreedDate && (!editingDue || editingDue.lastPaymentAgreedDate !== newAgreedDate)) {
          const newPromise: PromiseRecord = {
            id: `pr_${Date.now()}`,
            promisedDate: newAgreedDate,
            createdAt: new Date().toISOString(),
            status: 'PENDING',
            note: formData.shortNote || 'Promise date updated via form'
          };
          promiseHistory = [...promiseHistory, newPromise];
        }

        const due: DueItem = {
          id: editingDue ? editingDue.id : `d_${Date.now()}`,
          customerId,
          amount: parseFloat(formData.amount),
          paidAmount: editingDue ? editingDue.paidAmount : 0,
          dueDate: formData.dueDate,
          title: formData.title,
          status: editingDue ? editingDue.status : PaymentStatus.PENDING,
          createdAt: editingDue ? editingDue.createdAt : new Date().toISOString(),
          shortNote: formData.shortNote,
          lastPaymentDate: formData.lastPaymentDate || undefined,
          lastPaymentAgreedDate: formData.lastPaymentAgreedDate || undefined,
          paymentHistory: editingDue?.paymentHistory || [],
          promiseHistory: promiseHistory // Save the updated history
        };

        await StorageService.saveDue(due);
        await loadData(); // Reload to get fresh data
        setIsAddModalOpen(false);
        setEditingDue(null);
    } catch (error) {
        console.error("Save error:", error);
        alert("Failed to save.");
        setIsLoading(false);
    }
  };

  const openAdd = () => {
    setEditingDue(null);
    setIsAddModalOpen(true);
  }

  const openEdit = (due: DueWithCustomer) => {
    setEditingDue(due);
    setIsAddModalOpen(true);
  };

  // Open the detail view
  const openDetails = (due: DueWithCustomer) => {
    setViewingDue(due);
    setIsDetailModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this due?')) {
      setIsLoading(true);
      await StorageService.deleteDue(id);
      await loadData();
    }
  };

  const handleMarkPaid = async (id: string) => {
    const due = dues.find(d => d.id === id);
    if (due) {
      setIsLoading(true);
      const updatedDue = { ...due, status: PaymentStatus.PAID, paidAmount: due.amount };
      await StorageService.saveDue(updatedDue);
      await loadData();
      
      // If we are viewing details for this one, update the view state
      if (viewingDue && viewingDue.id === id) {
         setViewingDue({...viewingDue, ...updatedDue} as DueWithCustomer);
      }
    }
  };

  const handleGenerateReminder = async (due: DueWithCustomer) => {
    setReminderModalOpen(true);
    setReminderLoading(true);
    setReminderText('Generating polite reminder...');
    
    const text = await GeminiService.generateReminder(
      due.customer?.name || 'Customer', 
      due.amount - due.paidAmount, 
      due.dueDate, 
      'polite'
    );
    setReminderText(text || "Error generating reminder.");
    setReminderLoading(false);
  };

  // Notifications
  const overdueCount = dues.filter(d => d.status === PaymentStatus.OVERDUE).length;

  if (isLoading && dues.length === 0) {
      return (
          <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 text-gray-500 gap-4">
              <Loader2 className="animate-spin text-primary" size={48} />
              <p>Loading your data...</p>
          </div>
      )
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans pb-20 md:pb-0">
      
      {/* Top Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-30 px-4 py-3 flex flex-col gap-2">
        <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-primary">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold">D</div>
            <span className="font-bold text-xl tracking-tight hidden sm:block">DueTrack AI</span>
            </div>
            
            <div className="flex items-center gap-4">
            <div className="relative cursor-pointer group">
                <Bell className="text-gray-500 hover:text-indigo-600 transition" size={24} />
                {overdueCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full animate-pulse">
                    {overdueCount}
                </span>
                )}
                <div className="absolute right-0 mt-2 w-64 bg-white shadow-xl rounded-lg border border-gray-100 p-3 hidden group-hover:block">
                <p className="text-xs font-semibold text-gray-500 uppercase mb-2">Notifications</p>
                {overdueCount > 0 ? (
                    <div className="text-sm text-gray-700">You have {overdueCount} overdue payments needing attention.</div>
                ) : (
                    <div className="text-sm text-gray-500">You're all caught up! Great job.</div>
                )}
                </div>
            </div>
            <button 
                onClick={openAdd}
                className="hidden sm:flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-lg hover:shadow-lg transition font-medium"
            >
                <Plus size={18} />
                <span>Add Due</span>
            </button>
            </div>
        </div>

        {/* Database Status Banner */}
        {!isConfigured && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 flex items-center justify-between text-amber-800 text-xs sm:text-sm">
                <div className="flex items-center gap-2">
                    <WifiOff size={16} />
                    <span><strong>Demo Mode:</strong> Using Local Storage. Add Firebase keys to sync online.</span>
                </div>
            </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto p-4 md:p-6 lg:p-8">
        
        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar / Tabs (Desktop) */}
          <aside className="w-full md:w-64 flex-shrink-0 hidden md:block">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 sticky top-24">
              <div className="space-y-1">
                <button
                  onClick={() => setActiveTab('DASHBOARD')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition ${
                    activeTab === 'DASHBOARD' ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <LayoutGrid size={18} />
                  Dashboard
                </button>
                <button
                  onClick={() => setActiveTab('LIST')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition ${
                    activeTab === 'LIST' ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <List size={18} />
                  All Dues
                </button>
              </div>
            </div>
          </aside>

          {/* Content Area */}
          <div className="flex-1">
             <div className="mb-6 flex justify-between items-center md:hidden">
                <h1 className="text-2xl font-bold text-gray-800">{activeTab === 'DASHBOARD' ? 'Dashboard' : 'Due List'}</h1>
             </div>

             {activeTab === 'DASHBOARD' && <Dashboard dues={dues} />}
             {activeTab === 'LIST' && (
               <DueList 
                 dues={dues} 
                 onEdit={openEdit} 
                 onDelete={handleDelete} 
                 onMarkPaid={handleMarkPaid}
                 onGenerateReminder={handleGenerateReminder}
                 onViewDetails={openDetails}
               />
             )}
          </div>
        </div>
      </main>

      {/* Mobile Floating Action Button */}
      <div className="md:hidden fixed bottom-20 right-4 z-40">
        <button 
          onClick={openAdd}
          className="bg-indigo-600 text-white w-14 h-14 rounded-full shadow-lg flex items-center justify-center hover:bg-indigo-700 active:scale-95 transition"
        >
          <Plus size={24} />
        </button>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30 px-6 py-2 flex justify-between items-center">
         <button 
           onClick={() => setActiveTab('DASHBOARD')}
           className={`flex flex-col items-center gap-1 p-2 ${activeTab === 'DASHBOARD' ? 'text-indigo-600' : 'text-gray-400'}`}
         >
           <LayoutGrid size={20} />
           <span className="text-[10px] font-medium">Home</span>
         </button>
         <button 
           onClick={() => setActiveTab('LIST')}
           className={`flex flex-col items-center gap-1 p-2 ${activeTab === 'LIST' ? 'text-indigo-600' : 'text-gray-400'}`}
         >
           <List size={20} />
           <span className="text-[10px] font-medium">List</span>
         </button>
      </div>

      {/* Unified Add/Edit Modal */}
      {isAddModalOpen && (
        <SmartAddModal
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          onSave={handleSaveDue}
          editingDue={editingDue ? { 
            ...editingDue, 
            customerName: editingDue.customer?.name // HACK: Pass name into DueItem for Form
          } as any : null}
        />
      )}

      {/* Full Detail Modal */}
      {isDetailModalOpen && viewingDue && (
        <DueDetailModal 
          due={viewingDue}
          isOpen={isDetailModalOpen}
          onClose={() => setIsDetailModalOpen(false)}
          onMarkPaid={handleMarkPaid}
          onGenerateReminder={handleGenerateReminder}
        />
      )}

      {/* Reminder Preview Modal */}
      {reminderModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-[70] flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-6">
            <div className="flex items-center gap-2 mb-4 text-primary">
              <MessageSquare size={20} />
              <h2 className="text-lg font-bold">AI Reminder Draft</h2>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg text-gray-700 text-sm whitespace-pre-wrap min-h-[100px] border border-gray-200">
               {reminderLoading ? (
                 <div className="flex items-center gap-2 text-gray-400">
                   <div className="w-4 h-4 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                   Writing message...
                 </div>
               ) : reminderText}
            </div>
            
            <div className="mt-6 flex justify-end gap-3">
              <button 
                onClick={() => setReminderModalOpen(false)}
                className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
              >
                Close
              </button>
              <button 
                onClick={() => {
                  navigator.clipboard.writeText(reminderText);
                  alert('Copied to clipboard!');
                }}
                disabled={reminderLoading}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
              >
                Copy Text
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default App;